#!/usr/bin/env python3
#
# Recreate a readout file from a SI Readout unit in the same format as is created
# by SIConfig+. Data is collected from all the SI units used during an
# orienteering competition.
# This program can be used when the readout from SI cards has failed for some reason.

# Lennart Almström 2021-05-01
# Version 2.2: 2024-09-23

#    Copyright (C)    2023  Lennart Almström <lennart.almstrom@telia.com>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# This program uses sireader3 modified by me from sireader and sireader2
#    Copyright (C) 2008-2014  Gaudenz Steinlin <gaudenz@durcheinandertal.ch>
#                       2014  Simon Harston <simon@harston.de>
#                       2015  Jan Vorwerk <jan.vorwerk@angexis.com>
#                       2019  Per Magnusson <per.magnusson@gmail.com>

import datetime
import time
import sys
import os
import traceback
import configparser
import shutil
import csv
import operator

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment
import xmltodict
from sireader3 import SIReader, SIReaderException

class Adjustments(object):
    """Class to handle Adjustments.xlsx file.
    """

    def _set_alignment(self, afs):
        """Internal procedure to set alignments.

        :param: afs: Sheet object
        :return:
        """
        afs['B1'].alignment = Alignment(horizontal='right')
        afs['D1'].alignment = Alignment(horizontal='right')
        afs['F1'].alignment = Alignment(horizontal='right')
        afs['G1'].alignment = Alignment(horizontal='right')
        afs['H1'].alignment = Alignment(horizontal='right')
        afs['K1'].alignment = Alignment(horizontal='right')

    def create_new_adjustments_file(self):
        """Create and initialize Adjustments.xlsx.

        :param
        :return:
        """
        if os.path.exists(rp.adjustments_file):
            try:
                os.remove(rp.adjustments_file)
            except PermissionError as msg:
                print(f'{rp.adjustments_file} not accessible. Open in other program?')
                print(f'Close the other program and restart this program.')
                sys.exit(1)

        af = Workbook()
        afs = af.active
        afs.title = rp.sheet1name
        headers = ('Filename', 'Control', 'Mode', 'Serial', 'Time error', 'Voltage',
                   'Active time', 'Capacity', 'Firmware', 'Battery date', 'Battery %',
                   'Build date', 'Modification date', 'Last punch date')

        afs.append(headers)
        afs.column_dimensions['A'].width = 18
        afs.column_dimensions['B'].width = 8
        afs.column_dimensions['C'].width = 20
        afs.column_dimensions['D'].width = 8
        afs.column_dimensions['E'].width = 15
        afs.column_dimensions['F'].width = 8
        afs.column_dimensions['G'].width = 12
        afs.column_dimensions['H'].width = 10
        afs.column_dimensions['I'].width = 10
        afs.column_dimensions['J'].width = 13
        afs.column_dimensions['K'].width = 10
        afs.column_dimensions['L'].width = 12
        afs.column_dimensions['M'].width = 20
        afs.column_dimensions['N'].width = 20
        self._set_alignment(afs)
        afc = af.create_sheet(rp.sheet2name)
        headers = ('Competition date from', 'Competition date to')
        afc.append(headers)
        firstrow = (rp.dummy_competitiondate, rp.dummy_competitiondate)
        afc.append(firstrow)
        afc.column_dimensions['A'].width = 22
        afc.column_dimensions['B'].width = 22
        af.save(filename=rp.adjustments_file)
        shutil.copy2(rp.adjustments_file, rp.adjustments_backup)

    def read_adjustments_file(self):
        """Read all data from Adjustments.xlsx.

        :param
        :return: Tuple:
                 af: workbook object
                 afs: statistics sheet object
                 afsdata: list of lists containing data in statistics sheet
                 afc: compdate sheet object
                 afcdata: list of lists containing data in compdate sheet
        """
        if not os.path.exists(rp.adjustments_file):
            print(f'{rp.adjustments_file} does not exit')
            sys.exit(1)

        af = load_workbook(filename=rp.adjustments_file)
        afs = af[rp.sheet1name]
        afc = af[rp.sheet2name]

        # Empty outer list
        afsdata = []
        # Read only the first 14 columns
        for row in afs.iter_rows(min_row=1, min_col=1, max_row=afs.max_row, max_col=14):
            rowdata = []
            # Read rows and change None values to empty string
            rowempty = True
            for cell in row:
                if not cell.value in (None, ''):
                    rowempty = False
                rowdata.append('' if cell.value == None else cell.value)
            if not rowempty:
                afsdata.append(rowdata)

        # Empty outer list
        afcdata = []
        # Read only the first two columns
        for row in afc.iter_rows(min_row=1, min_col=1, max_row=afc.max_row, max_col=2):
            rowdata = []
            # Read rows and change None values to empty string
            rowempty = True
            for cell in row:
                if not cell.value in (None, ''):
                    rowempty = False
                rowdata.append('' if cell.value == None else cell.value)
            if not rowempty:
                afcdata.append(rowdata)

        return af, afs, afsdata, afc, afcdata

    def write_adjustments_file(self, af, afs, afsdata, afc, afcdata):
        """Replace all data in Adjustments.xlsx.

        :param: af: workbook object
                afs: statistics sheet object
                afsdata: list of lists containing data in statistics sheet
                afc: compdate sheet object
                afcdata: list of lists containing data in compdate sheet

        :return:
        """
        afs.delete_rows(1, afs.max_row)
        afc.delete_rows(1, afc.max_row)

        for row in afsdata:
            afs.append(row)

        for row in afcdata:
            afc.append(row)

        self._set_alignment(afs)

        try:
            af.save(filename=rp.adjustments_file)
            shutil.copy2(rp.adjustments_file, rp.adjustments_backup)
        except PermissionError as msg:
            print(f'{rp.adjustments_file} or {rp.adjustments_backup} not accessible. Open in other program?')
            print(f'Close the other program and reread this SI station to update {rp.adjustments_file}.')
            sys.exit(1)

    def update_adjustments(self, af, afs, afsdata, afc, afcdata, csvfilename, newctldata):
        """Replace or add a row of data in afdata and rewrite the xlsx file.

        :param: af: workbook object
                afs: statistics sheet object
                afsdata: list of lists containing data in statistics sheet
                afc: compdate sheet object
                afcdata: list of lists containing data in compdate sheet
                csvfilename: filename of file containing punches
                newctldata: list containing new data to be added or replaced:
                    ctlnbr: Control number for control
                    ctlmode: type of control
                    ctlserialnbr: Serial number for control
                    timediff_str: string containing time error in format +-hh:mm:ss.ttt
                    ctlvoltage: battery voltage of control
                    ctlactivetime: active time of control
                    ctlbatcap: battery capacity of control
                    ctlvoltage: battery voltage of control
                    ctlfirmware: firmware level of control
                    ctlbatterydate: battery date of control
                    ctlbatleft: percent remaining battery capacity of control
                    ctlbuilddate: build date of control
                    ctllastmodifdate: last modification date and time of control
                    ctllastpunchdate: last punch date and time of control

        :return: afsdata (updated), afcdata
        """
        row_updated = False

        # Build the new data row for statistics sheet
        newrow = [csvfilename] + newctldata
        # Search for the row to be replaced and replace it if found
        for rownbr in range(1, len(afsdata)):
            if afsdata[rownbr][0] == csvfilename:
                afsdata[rownbr] = newrow
                row_updated = True
        # If row not found, add a new row
        if not row_updated:
            afsdata.append(newrow)

        # Write to excel file
        rp.adj.write_adjustments_file(af, afs, afsdata, afc, afcdata)
        return afsdata, afcdata

class Do_convert(object):
    """Class to do conversion work.
    """

    def readcu(self):
        """Read punch data from SI control units and update excel file with data from punch files.

        :param:

        :return:
        """

        def _callsi(method):
            """Internal method to issue a simple call without parameters to SIReader
               and handle errors from the call.

            :param:

            :return: True/False to indicate success or not of call to SIReader
                     Value returned by SIReader
            """
            ok = False
            errmsg = ''
            for ii in range(0, maxretries):
                try:
                    datavalue = method()
                    ok = True
                    break;
                except SIReaderException as msg:
                    errmsg = msg
                    time.sleep(0.5)
            if not ok:
                print(f'ERROR: Failed to talk to the station ({method.__name__}): %s' % errmsg)
                print(f'  {errmsg}')
                print('Maybe the station is not connected or not awake?')
                print('Try to disconnect and reconnect the USB cable to the computer ')
                print('and/or lift the control unit from the readout unit and put it down again.')
                print('If that does not help, press q and restart this program.')
                return False, None
            return True, datavalue

        # This is the start of code for readcu

        # If this is first run for this competition, create and initialize the excel file
        # and remove old punch files if there are any
        firstsession = False
        inp = input('Is this the first control unit read session for this competition? (y/n)')
        if inp.upper() in ('Y', 'J'):
            firstsession = True

        if firstsession:
            rp.adj.create_new_adjustments_file()

            punchfiles = (os.listdir(rp.punches_subdir))

            for filename in punchfiles:
                os.remove(rp.punches_subdir + '\\' + filename)

        # Read in all data from the excel file
        af, afs, afsdata, afc, afcdata = rp.adj.read_adjustments_file()

        # Connect to the SI Readout station
        try:
                # Find serial port automatically
            si = SIReader(debug=False)
            print('Connected to station on port ' + si.port)
        except:
            print('Failed to connect to an SI station on any of the available serial ports.')
            sys.exit()

        # Set station in remote mode
        ok = False
        errmsg = ''
        for ii in range(0, 3):
            try:
                si.set_remote()
                ok = True
                break;
            except SIReaderException as msg:
                errmsg = msg
                time.sleep(0.5)
        if not ok:
            print('ERROR: Failed to set station in remote mode: %s' % errmsg)
            sys.exit()

        # Read backup data from SI station when user presses Enter
        print('Ready to read backup memory of SI station.')
        maxretries = 5
        while True:
            inp = input('    Press <Enter> to read next remote station, or q to quit.')
            if inp == 'q':
                break
            elif inp == '':
                if si.direct:
                    si.set_remote()
            else:
                print('    Unrecognized input')
                continue

            valueok, dummy = _callsi(si._update_proto_config)
            if not valueok:
                continue

            readbackup = True
            if not si.proto_config['mode'] in si.SUPPORTED_READ_BACKUP_MODES:
                readbackup = False

            # Find out the time error of this SI station.
            # Get the wall clock both before and after reading the SI station time
            # and take the mean value of the wall clock readings.
            wallclocktime1 = datetime.datetime.now()
            # Get the SI station time.
            valueok, stationtime = _callsi(si.get_time)
            if not valueok:
                continue

            wallclocktime2 = datetime.datetime.now()
            wallclocktime = wallclocktime1 + ((wallclocktime2 - wallclocktime1) / 2)
            # Make the time difference positive and remember the correct plus/minus sign.
            if wallclocktime > stationtime:
                diffsign = '-'
                timediff = wallclocktime - stationtime
            else:
                diffsign = '+'
                timediff = stationtime - wallclocktime
            timediff_str = str(timediff)
            # If the time difference has a millisecond part, make it consist of exactly three decimals
            parts = timediff_str.split('.')
            if len(parts) == 2:
                parts[1] = (parts[1] + '000')[:3]
                timediff_str = '.'.join(parts)
            # Remove zero parts from the beginning of the time difference string
            newtimediff_str = timediff_str
            for char in timediff_str:
                if char in ('0', ':'):
                    newtimediff_str = newtimediff_str[1:]
                else:
                    break
            # Finally add a zero if everything was removed from the integer part (just to make it look better)
            if newtimediff_str[0] == '.':
                newtimediff_str = f'0{newtimediff_str}'
            timediff_str = newtimediff_str

            # Get the active time of the control
            valueok, ctlactivetime = _callsi(si.sysval_active_time)
            if not valueok:
                continue

            # Get the battery capacity of the control
            valueok, ctlbatcap_float = _callsi(si.sysval_battery_capacity)
            if not valueok:
                continue

            ctlbatcap = round(ctlbatcap_float, 0)

            # Get the firmware level of the control
            valueok, ctlfirmware = _callsi(si.sysval_fwver)
            if not valueok:
                continue

            # Get the battery date of the control
            valueok, ctlbatterydate = _callsi(si.sysval_battery_date)
            if not valueok:
                continue

            # Get the battery used percent of the control and make it battery left percent
            valueok, ctlbatused_float = _callsi(si.sysval_used_battery)
            if not valueok:
                continue

            ctlbatleft = round(100.0 - ctlbatused_float, 0)

            # Get the build date of the control
            valueok, ctlbuilddate = _callsi(si.sysval_build_date)
            if not valueok:
                continue

            # Get the last modification date of the control
            valueok, ctllastmodifdate_datetime = _callsi(si.sysval_lastmodif_datetime)
            if not valueok:
                continue
            ctllastmodifdate = str(ctllastmodifdate_datetime)[:19]

            # Get the battery voltage of the control
            valueok, ctlvoltage_float = _callsi(si.sysval_volt)
            if not valueok:
                continue

            ctlvoltage = round(ctlvoltage_float, 2)

            # Build the filename for the punches file
            ctlnbr = si._station_code
            ctlserialnbr = si._serno
            ctlmode = si.sysval_mode_str()
            if ctlmode[0:4] == 'SIAC':
                ctlnbr = 0
            ctlmode4 = ctlmode[:4].replace(' ', '_')
            csvfilename = f'{ctlmode4}{str(ctlnbr)}_{str(ctlserialnbr)}.csv'

            ctllastpunchdate = ''
            backup = []
            if readbackup:
                # Read the backup memory from the SI station
                for ii in range(0, maxretries):
                    try:
                        # print('    Trying to read backup memory of station: ' + str(ctlnbr) + ' ', end='')
                        print('    Trying to read backup memory of station: ' + str(ctlnbr) + ' ')
                        sys.stdout.flush()
                        backup = si.read_backup(progress=1)
                        ok = True
                        break
                    except SIReaderException as msg:
                        print('')
                        time.sleep(0.5)
                        errmsg = msg
                    if not ok:
                        print('ERROR: Failed to talk to the station (read_backup): %s' % errmsg)
                        print('Maybe the station is not connected, not awake or not in a supported mode?')
                        print('Try to disconnect and reconnect the USB cable to the computer ')
                        print('and/or lift the control unit from the readout unit and put it down again.')
                        print('If that does not help, press q and restart this program.')
                        continue

                # If this is the first SI station that has punches, use the date of the last punch
                # as competition date.
                if len(backup) > 0 \
                        and afcdata[1][0] == rp.dummy_competitiondate:
                    # Get first 10 positions (= punch date) from the first column in the last row
                    # and set it as both first and last competition date.
                    afcdata[1][0] = str(backup[-1][0])[:10]
                    afcdata[1][1] = afcdata[1][0]

                # Remember the last punch time on this control
                if len(backup) > 0:
                    # Get date and time from the first column in the last row
                    ctllastpunchdate = str(backup[-1][0])[:11] + str(backup[-1][0])[11:19]

            # Create a new punch file in Punches subdirectory
            csvpathfilename = rp.punches_subdir + '\\' + csvfilename
            if readbackup:
                csvpathfilename = si.write_backup_csv(backup,filename=csvpathfilename)
                print(f'{csvpathfilename} was created, number of punches is {len(backup)}.')
                if len(backup) == 0:
                    print(f'No punches were read from this unit.')
                    print(f'If it was used, please read it once more.')
            else:
                print(f'{csvpathfilename} not created because this control type does not have punches')

            # Update or add data for this file to the excel file
            ctldata = [ctlnbr, ctlmode, ctlserialnbr, timediff_str, ctlvoltage,
                       ctlactivetime, ctlbatcap, ctlfirmware, ctlbatterydate,
                       ctlbatleft, ctlbuilddate, ctllastmodifdate, ctllastpunchdate]
            afsdata, afcdata = rp.adj.update_adjustments(af, afs, afsdata, afc, afcdata,
                                               csvfilename, ctldata)

            # Turn off the SI station if so is requested, else let it beep only
            if rp.si_turnoff:
                valueok, dummy = _callsi(si.poweroff)
                if not valueok:
                    continue
            else:
                valueok, dummy = _callsi(si.beep)
                if not valueok:
                    continue


    def joinfiles(self):
        """Read all the collected punch files, adjust punching times and create
            a file containing all punches ordered by partipicant and punch timedata from SI control units.

        :param:

        :return:
        """

        def _is_float(string):
            """Internal method to check if a string contains a float number.

            :param: string: string to be tested

            :return: True or False
            """
            try:
                float(string)
                return True
            except ValueError:
                return False

        def _correct(fileline, correctdates, errorspec, filename, correct_times, approve_ErrA):
            """Internal method to correct the punch time of one punch. It also checks if the punch
                has been done on the competition date, otherwise the punch is ignored.

            :param: fileline: tuple containing the values from one punch reading
                    correctdate: tuple containing correct competition dates from and to
                    errorspec: tuple containing the proper row data from the excel file
                    filename: name of the punches file
                    correct_times: if True, do time corrections
                    approve_ErrA: if True, approve punches marked ErrA

            :return: fileline containing corrected data, or empty string if this punch
                     should be ignored because of wrong date.
            """
            # Split data from excel file row.
            # Note that the correction time is provided in seconds with 3 decimals.
            ctlnbr, ctlserialnbr, errsecs, correctfilename = errorspec

            # Make a list of the punch file data line
            filedata = fileline.split(';')

            # If millisecond part of punch time is missing, add three zeroes
            # to both fields containing punch time
            if len(filedata[3]) == 21:
                filedata[3] += '.000'
            if len(filedata[8]) == 8:
                filedata[8] += '.000'

            # Use while True only to be able to break
            while True:
                # Prepare updated punch file line in case we break without changes
                newfileline = ';'.join(filedata)
                # If the SI station reports that an ErrA has occured at punch time,
                # and if ErrA should not be approved, ignore the punch.
                if not approve_ErrA:
                    if filedata[3][13:17] == 'ErrA':
                        newfileline = ''
                        break
                # If the SI station reports that an error has occured at punch time,
                # do no more correction of the data
                if filedata[3][13:16] == 'Err':
                    break
                # If this is not an interesting type of contol, don't correct
                if filedata[9] not in ('Control', 'Start', 'Finish', 'Clear', 'Check',
                                        'BcControl', 'BcStart', 'BcFinish'):
                    break
                # If this is not the proper control number to correct, don't correct
                if filedata[9] in ('Control', 'BcControl') and int(filedata[6]) != ctlnbr:
                    break
                # Control number for a Start unit, has internally in this program been set to -1
                # to recognize it. If this is not a Start unit, don't correct
                if filedata[9] in ('Start', 'BcStart') and ctlnbr != -1:
                    break
                # Same for a Finish unit
                if filedata[9] in ('Finish', 'BcFinish') and ctlnbr != -2:
                    break
                # Same for a Clear unit
                if filedata[9] == 'Clear' and ctlnbr != -3:
                    break
                # Same for a Check unit
                if filedata[9] == 'Check' and ctlnbr != -4:
                    break
                # If a punch file name has been registered in the excel file, check that this
                # punch comes from that punch file. If not, don't correct.
                if correctfilename.strip() != '':
                    if filename != correctfilename:
                        break

                # We have passed all the tests except the correct date test. That can only
                # be tested when we have corrected the punch time.

                # Correct the punch time according to the time correction in the excel file
                datetimetocorrect = filedata[3]
                # If time corrections should not be applied, we already have a correct date
                if not correct_times:
                    correcteddate = datetimetocorrect[:10]
                # Otherwise correct the datetime
                else:
                    datetimetocorrect_dt = datetime.datetime.strptime(datetimetocorrect, '%Y-%m-%d %H:%M:%S.%f')
                    correcteddatetime_dt = datetimetocorrect_dt - datetime.timedelta(seconds=errsecs)
                    correcteddatetime = datetime.datetime.strftime(correcteddatetime_dt, '%Y-%m-%d   %H:%M:%S.%f')[:25]
                    correcteddate = correcteddatetime[:10]

                    # Replace the punch date and time in the punch file data line
                    filedata[3] = correcteddatetime
                    filedata[8] = correcteddatetime[13:]

                    # print(f'{correcteddate} {correctdates[0]} {correctdates[1]}')

                # If punch is from wrong date, ignore it
                if correcteddate < correctdates[0] or correcteddate > correctdates[1]:
                    newfileline = ''
                    break

                # Make the row semicolon separated
                newfileline = ';'.join(filedata)
                # Here are some code lines to print the correction if needed for debugging
                # if ctlnbr == -1:
                #     ctlname = 'Start'
                # elif ctlnbr == -2:
                #     ctlname = 'Finish'
                # elif ctlnbr == -3:
                #     ctlname = 'Clear'
                # elif ctlnbr == -4:
                # ctlname = 'Check'
                # else:
                #     ctlname = str(ctlnbr)
                # print(f'Control {ctlname}, file {filename} corrected '
                #       f'from {datetimetocorrect} to {correcteddatetime}')
                break

            return newfileline
            # End of "_correct" internal method

        # This is the beginning of code for the "joinfiles" method

        # Check if time corrections should be used
        # (only check with user if config file specifies correction)
        correct_times = False
        if rp.correct_times:
            reply = input(f'Should time corrections in {rp.adjustments_file} be applid. Reply y or n for yes or no.')
            if reply.upper() in ('Y', 'J'):
                correct_times = True

        # Get data from the excel file
        af, afs, afsdata, afc, afcdata = rp.adj.read_adjustments_file()
        print(f'The Excel file {rp.adjustments_file} contains the following information:')
        LAYOUT = "{!s:18} {!s:8} {!s:20} {!s:8} {!s:15} {!s:8} {!s:12} {!s:10} " \
                 "{!s:10} {!s:13} {!s:10} {!s:12} {!s:20} {!s:20}"
        for line in afsdata:
            print(LAYOUT.format(*line))
        print('')
        LAYOUT = "{!s:22} {!s:22}"
        for line in afcdata:
            print(LAYOUT.format(*line))
        print('')
        reply = input(f'Is this the correct file? Reply y or n for yes or no.')
        if reply.upper() not in ('Y', 'J'):
            sys.exit(1)

        # Check if ErrA punches should be approved
        approve_ErrA = False
        if rp.approve_ErrA:
            reply = input(f'Should ErrA punches be approved? (They are normally not approved.) Reply y or n for yes or no.')
            if reply.upper() in ('Y', 'J'):
                approve_ErrA = True

        # Get competion dates from excel file. If the user has changed them, they might have become
        # a datetime values, so make them strings again.
        correctdatefrom = afcdata[1][0]
        if isinstance(correctdatefrom, datetime.datetime):
            correctdatefrom = str(correctdatefrom)[:10]
        try:
            datetime.date.fromisoformat(correctdatefrom)
        except ValueError:
            print(f'Date "{correctdatefrom}" in cell A2 is not in correct date format')
            sys.exit(1)

        correctdateto = afcdata[1][1]
        if correctdateto == '':
            correctdateto = correctdatefrom
        else:
            if isinstance(correctdateto, datetime.datetime):
                correctdateto = str(correctdateto)[:10]
            try:
                datetime.date.fromisoformat(correctdateto)
            except ValueError:
                print(f'Date "{correctdateto}" in cell B2 is not in correct date format')
                sys.exit(1)
        correctdates = (correctdatefrom, correctdateto)

        # Make the error specification from excel data. Some error checking is done if it has
        # been modified or built by the user.
        # The error specification is a list of lists containing all time errors to be corrected.
        errorspecs = []
        for rownbr in range(1,len(afsdata)):
            headers = ('Filename', 'Control', 'Mode', 'Serial', 'Time error', 'Voltage',
                       'Active time', 'Capacity', 'Firmware', 'Battery date', 'Battery %',
                       'Build date', 'Modification date', 'Last punch date')

            # Split the current row of data from the excel file
            curfilename, curctlnbr, curmode, curserialnbr, curerror = afsdata[rownbr][:5]
            # Check the error spec and set internal control numbers for Start and Finish units
            if curerror == '':
                curerror = '0'
            if curerror[0] not in ('+', '-'):
                curerror = '+' + curerror
            if curmode in ('Start', 'BcStart'):
                curctlnbr = -1
            elif curmode in ('Finish', 'BcFinish'):
                curctlnbr = -2
            elif curmode == 'Clear':
                curctlnbr = -3
            elif curmode == 'Check':
                curctlnbr = -4
            elif curmode in ('Control', 'BcControl'):
                if not str(curctlnbr).isnumeric():
                    print(f'Control number {curctlnbr} on line {rownbr} in ' \
                          f'{rp.adjustments_file} is not numeric')
                    sys.exit(1)
                curctlnbr_num = int(curctlnbr)
                if curctlnbr_num < 31 \
                    or curctlnbr_num > 511:
                    print(f'Control {curctlnbr} on line {rownbr}' \
                          f' of {rp.adjustments_file} must be in range 31 - 511')
                    sys.exit(1)

            if curerror[0] not in('+', '-'):
                print(f'Error correction time on line {rownbr}' \
                      f' of {rp.adjustments_file} must start with + or -')
                sys.exit(1)
            curerrparts = curerror[1:].split(':')
            errsecs = 0
            for part in curerrparts:
                if not _is_float(part):
                    print(f'Error correction time on line {rownbr}' \
                          f' of {rp.adjustments_file} contains an unnumeric part')
                    sys.exit(1)
                errsecs = 60 * errsecs + float(part)
            if curerror[0] == '-':
                errsecs = - errsecs
            if curfilename.strip() != '':
                if curfilename[-4:] != '.csv':
                    print(f'Filename on line {rownbr}' \
                          f' of {rp.adjustments_file} must end in .csv')

            # Add this row to the error specification
            errorspecs.append([curctlnbr, curserialnbr, errsecs, curfilename])

        # Error specification has been built.
        # Now read all the punch files and apply the time corrections.
        nbrinfiles = 0
        nbroutlines = 0
        headerline = 'X'

        # Get the names of the punch files
        punchfiles = (os.listdir(rp.punches_subdir))
        punchfiles.sort()

        # Open the output file to collect all the punches
        with open(rp.join_unsorted_file, 'w') as outfile:
            # Handle each punch file
            for filename in punchfiles:
                # Handle only .csv files (ignoring other file types)
                ext = os.path.splitext(filename)
                if ext[1] == '.csv':
                    nbrinfiles += 1
                    # Open the punch file
                    with open(rp.punches_subdir + '\\' + filename) as infile:
                        infilelines = 0
                        # Read each line
                        for infileline in infile:
                            infilelines += 1
                            # Save the header from the first punch file to reuse it in the output file
                            if nbrinfiles == 1 and infilelines == 1:
                                headerline = infileline
                            # Ignore all header lines
                            if infilelines > 1 and infileline != '':
                                # Apply each error specification line to each punch file line.
                                # If they do not match, the correction will be ignored.
                                for errorspec in errorspecs:
                                    infileline = _correct(infileline, correctdates,
                                                          errorspec, filename,
                                                          correct_times, approve_ErrA)
                                    # If any of the error specs tells us to ignore this file line, do not
                                    # try any more error specs for this file line.
                                    if infileline == '':
                                        break
                                # If the _correct method tells us to ignore this line, do it,
                                # otherwise write the line to the unsorted intermittent file.
                                if infileline != '':
                                    nbroutlines += 1
                                    outfile.write(infileline)

        # Read the unsorted file and collect all its data in "datain".
        datain = []
        inrownbr = 0
        with open(rp.join_unsorted_file) as csv_file:
            csvreader = csv.reader(csv_file, delimiter=';')

            for row in csvreader:
                inrownbr += 1
                datain.append(row)

        print(nbrinfiles, 'csv files read,', nbroutlines, 'lines written to', rp.join_unsorted_file)

        # Sort the data read from the unsorted file on SIID (column 3) and corrected punch time (column 9)
        datain.sort(key=operator.itemgetter(2, 8))

        # Open the file to contain the sorted data
        with open(rp.join_sorted_file, mode='w', newline='') as outfile:
            # Get a csv writer object
            outfile_writer = csv.writer(outfile, delimiter=';', quotechar="'", quoting=csv.QUOTE_MINIMAL)
            # Remove the last semicolon in header
            headerline = headerline[:-1]
            # First write the saved header line after splitting it (as the csv writer needs a list)
            headerline_split = headerline.split(';')
            outfile_writer.writerow(headerline_split)
            # Then write all the sorted rows
            for row in datain:
                outfile_writer.writerow(row)

        print(rp.join_unsorted_file, 'has been sorted into', rp.join_sorted_file)


    def getstarttimes(self):
        """For classes with fixed start times and no start punching, this method reads the start times xml file
           from Eventor and creates an excel file with all fixed start times.
           The excel file is later read by the create method to insert the fixed start times in the output file
           from create.

        :param:

        :return:
        """
        # Check if the file from Eventor with start times has been provided.
        if not os.path.exists(rp.starttimes_eventor):
            print(f'File {rp.starttimes_eventor} does not exist.')
            print(f'Please export it from Eventor and name it {rp.starttimes_eventor} ')
            print(f'before running this procedure.')
            sys.exit(1)

        # Read the file
        with open(rp.starttimes_eventor, 'r', encoding='utf-8') as file:
            xmldata = file.read()
        # Parse the xml file using the xmltodict module.
        tree = xmltodict.parse(xmldata)
        excellines = []
        classstart = tree['StartList']['ClassStart']
        for runclass in classstart:
            curclass = runclass['Class']['Name']
            for personstart in runclass['PersonStart']:
                if 'ControlCard' not in personstart['Start']:
                    continue
                familyname = personstart['Person']['Name']['Family']
                givenname = personstart['Person']['Name']['Given']
                club = personstart['Organisation']['Name']
                startdatetime = personstart['Start']['StartTime']
                startdate = startdatetime[:10]
                starttime = startdatetime[11:19]
                sicard = personstart['Start']['ControlCard']
                # Build a tuple for the cells for one excel line.
                excelline = (sicard, starttime, f'{givenname} {familyname}', club, curclass, startdate)
                excellines.append(excelline)

        # Create an excel file from the values collected.
        start = Workbook()
        starts = start.active
        starts.title = 'Start times'
        headers = ('SI Number', 'Start time', 'Name', 'Club', 'Class', 'Start date')

        starts.append(headers)
        starts.column_dimensions['A'].width = 12
        starts.column_dimensions['B'].width = 10
        starts.column_dimensions['C'].width = 30
        starts.column_dimensions['D'].width = 30
        starts.column_dimensions['E'].width = 18
        starts.column_dimensions['F'].width = 12
        for excelline in excellines:
            starts.append(excelline)
        start.save(filename=rp.starttimes_corrected)
        print(f'File {rp.starttimes_corrected} has been created.')
        print(f'Open it and check if manual correctionas are necessary.')


    def create(self):
        """Create a readout file in the same format as SIConfig would create from
           a SI Readout unit.
           If start times from Eventor have been provided, get them from the excel file Starttimes.xlsx.

        :param:

        :return:
        """

        def _find_cards_read_out():
            """Internal procedure to retrieve SI Card numbers from lastbackup.meosxml that
               do not have a <Finished> block.

            :param:
            :return: set of SI Card numbers
            """
            # Read the file
            with open(rp.lastmeosbackup, 'r', encoding='utf-8') as file:
                xmldata = file.read()
            # Parse the xml file using the xmltodict module.
            tree = xmltodict.parse(xmldata)

            # If the runner has a Finish block, store his SI Card number in a set.
            readout_sicards = set()
            for runner in tree['meosdata']['RunnerList']['Runner']:
                if 'Finish' in runner:
                    readout_sicards.add(runner['CardNo'])
            return readout_sicards

        # This is the beginning of code for the "create" method

        # Check if there is a lastmeosbackup file and not a lastmeosbackup_cleaned file
        remove_cards_already_read_out = False
        if os.path.exists(rp.lastmeosbackup) \
        and not os.path.exists(rp.lastmeosbackup_cleaned):
            print(35 * '= ')
            print(f'File {rp.lastmeosbackup} exists but not {rp.lastmeosbackup_cleaned}.')
            print(f'Therefore the results in {rp.lastmeosbackup} that have already')
            print(f'been read out will be kept, by removing them from')
            print(f'the Readout file created by this function.')
            print(f'That way they will not be fed into MeOS once more.')
            print(f'Make sure that you import the {rp.lastmeosbackup} file to MeOS before')
            print(f'importing the Readout file from this function.')
            print(35 * '= ')

            # If so, get the SI cards already read out from the lastmeosbackup file
            remove_cards_already_read_out = True
            read_out_cards = _find_cards_read_out()

        # Check if there is a start times excel file
        fixedstarttimes = False
        if os.path.exists(rp.starttimes_corrected):
            fixedstarttimes = True
            # Read the excel file.
            fixstart = load_workbook(filename=rp.starttimes_corrected)
            fixstarts = fixstart.active

            # Initiate empty dictionary to contain key = siid and data = start time
            fixstartdata = {}
            # Read only the first 2 columns and skip the first row containing headers.
            for row in fixstarts.iter_rows(min_row=2, min_col=1, max_row=fixstarts.max_row, max_col=2):
                rowdata = []
                # Read rows and change None values to empty string
                rowempty = True
                for cell in row:
                    if not cell.value in (None, ''):
                        rowempty = False
                    rowdata.append('' if cell.value == None else cell.value)
                # Create a dictionary entry and make sure the siid is a string as it is a string in our input file
                # from join_files. Also insure that the time is a string in case it has been modified manually
                # in the excel file.
                if not rowempty:
                    fixstartdata[str(rowdata[0])] = str(rowdata[1])

        # Read the sorted file from the joinfiles method and collect the data in datain.
        datain = []
        inrownbr = 0
        with open(rp.join_sorted_file) as csv_file:
            csvreader = csv.reader(csv_file, delimiter=';')

            for row in csvreader:
                inrownbr += 1
                if inrownbr > 1:
                    datain.append(row)

        # Prepare a list of lists for the readout data file.
        dataout = []

        # Create the header line
        header_string = 'No;Read on;SIID;Start no;Clear CN;Clear DOW;Clear time;Clear_r CN;Clear_r DOW;' + \
                        'Clear_r time;Check CN;Check DOW;Check time;Start CN;Start DOW;Start time;Start_r CN;' + \
                        'Start_r DOW;Start_r time;Finish CN;Finish DOW;Finish time;Finish_r CN;Finish_r DOW;' + \
                        'Finish_r time;Class;First name;Last name;Club;Country;Email;Date of birth;Sex;Phone;' + \
                        'Street;ZIP;City;Hardware version;Software version;Battery date;Battery voltage;' + \
                        'Clear count;Character set;SEL_FEEDBACK;No. of records;'

        for punchno in range(1, 193):
            punchheader = 'Record ' + str(punchno) + ' '
            header_string += punchheader + 'CN;' + punchheader + 'DOW;' + punchheader + 'time;'

        # Remove the last semicolon and put the header line in dataout
        header_string = header_string[:-1]
        headers = header_string.split(';')
        dataout.append(headers)

        # Initiate variables to control the loop
        inrowno = -1
        outrowno = 0
        current_siid = ''

        # Loop running through all punches
        while True:

            # Next line in input data. Data starts on second line, bypassing the header line.
            inrowno += 1

            # The tests below only to be done if we have not reached the end of data.
            if inrowno < len(datain):

                # If it is not the last data line
                if inrowno < len(datain) - 1:

                    # If next line is for the same SIID as the current line
                    # print(datain[inrowno][2], type(datain[inrowno][2]))
                    if datain[inrowno][2] == datain[inrowno + 1][2]:

                        # If both this line and the next are Start punches, the runner has punched Start
                        # more than once. Ignore this line and rather use the next Start punch.
                        if datain[inrowno][9] in ('Start', 'BcStart') and \
                                datain[inrowno + 1][9] in ('Start', 'BcStart'):
                            continue

            # The first test means end of data,
            # the second indicates a new SIID on this line,
            # the third indicates a new sequence of Clear, Check, and/or Start punches
            # with the same SIID, so it is reuse of the same SI card.
            # In all these cases it is time to create a new line for the Readout data file.
            breaking_controls = ['Start', 'BcStart', 'Clear', 'Check']
            if inrowno >= len(datain) or \
                    current_siid != datain[inrowno][2] or \
                    (inrowno > 1 \
                     and datain[inrowno][9] in (breaking_controls) \
                     and datain[inrowno - 1][9] not in (breaking_controls) \
                    ):
            # If this is not the first runner, store the number of punches in the old line
                # and save it as a new output line.
                if current_siid != '':
                    newoutrow[44] = nbrcontrols
                    if remove_cards_already_read_out:
                        if newoutrow[2] not in read_out_cards:
                            dataout.append(newoutrow)
                        else:
                            # Decrease outrowno as no new row is written.
                            outrowno -= 1
                    else:
                        dataout.append(newoutrow)

                # If this is end of data, leave the loop.
                if inrowno >= len(datain):
                    break

                # Now we start handling a new output line.
                outrowno += 1
                nbrcontrols = 0
                outcolno = 45  # Punch data start in column 46

                # Readout time is in column 2
                readtime = datain[inrowno][1]

                # SIID is in column 3
                current_siid = datain[inrowno][2]

                # The first four output columns contain:
                # Line number, Readout time, SIID, and constant 1
                newoutrow = [''] * 45
                newoutrow[0] = outrowno
                newoutrow[1] = readtime
                newoutrow[2] = current_siid
                newoutrow[3] = 1

            # Get the punch time from column 9
            punchtime = str(datain[inrowno][8])[0:8]

            # Start time is in column 16 of the output file
            if datain[inrowno][9] in ('Start', 'BcStart'):
                newoutrow[15] = punchtime
                # If we have a fixed start time, use it
                if fixedstarttimes:
                    if current_siid in fixstartdata:
                        newoutrow[15] = fixstartdata[current_siid]

            # Finish time is in column 22 of the output file
            if datain[inrowno][9] in ('Finish', 'BcFinish'):
                newoutrow[21] = punchtime

            # Clear time is set in the clear and check columns 7 and 13 of the output file
            if datain[inrowno][9] == 'Clear':
                newoutrow[6] = punchtime
                newoutrow[12] = punchtime

            # Check time is in column 7 and 13 of the output file and the clear time
            # is moved to column 10 to mimic the behaviour of SIConfigPlus found empirically and
            # susggested  by https://www.attackpoint.org/discussionthread.jsp/message_1475911.
            if datain[inrowno][9] == 'Check':
                newoutrow[9] = newoutrow[6]
                newoutrow[6] = punchtime
                newoutrow[12] = punchtime

            # This is a control punch, its data are to be put in the next 3 columns.
            if datain[inrowno][9] in ('Control', 'BcControl'):
                controlno = datain[inrowno][6]
                newoutrow.append(controlno)
                newoutrow.append('')
                newoutrow.append(punchtime)
                outcolno += 3
                nbrcontrols += 1

        # Everything is read and the output is built, save the built Readout file.
        with open(rp.create_out_file, mode='w', newline='') as outfile:
            outfile_writer = csv.writer(outfile, delimiter=';', quotechar="'", quoting=csv.QUOTE_MINIMAL)

            for row in dataout:
                outfile_writer.writerow(row)

        print(outrowno + 1, 'data lines written to', rp.create_out_file)


    def cleanmeosbackup(self):
        """Remove all registered SI card punches from a MeOS backup file
           to make it look like a backup with only registered runners without any results yet.

        :param:

        :return:
        """
        # Check if the MeOS backup file has been provided.
        if not os.path.exists(rp.lastmeosbackup):
            print(f'File {rp.lastmeosbackup} does not exist.')
            print(f'Please copy your last MeOS backup and name it {rp.lastmeosbackup} ')
            print(f'before running this procedure.')
            sys.exit(1)

        # Read the file
        with open(rp.lastmeosbackup, 'r', encoding='utf-8') as file:
            xmldata = file.read()
        # Parse the xml file using the xmltodict module.
        tree = xmltodict.parse(xmldata)

        # Remove the Card and Finish blocks for all runners.
        for runner in tree['meosdata']['RunnerList']['Runner']:
            if 'Card' in runner:
                del runner['Card']
            if 'Finish' in runner:
                del runner['Finish']

        # Remove the Card block from CardList.
        del tree['meosdata']['CardList']['Card']

        # Recreate the meosxml file and write it to a new "cleaned" file.
        xmldata = xmltodict.unparse(tree)
        with open(rp.lastmeosbackup_cleaned, 'w', encoding='utf-8') as file:
            file.write(xmldata)
        print(f'MeOS backup file cleaned, {rp.lastmeosbackup_cleaned} has been created.')


class Service(object):
    """Class to handle common service functions:
        Logging
    """

    def __init__(self, config) -> None:
        """__init__

        :param config: Configuration data
        :return:
        """

        self.cfg = config
        self.logfile = self.cfg["Files"]["Logfile"]

    def writelog(self, text: str):
        """Write one or more lines to the log file.

        :param text: Text string to write. A newline is appended at the end
                     of the text.
        :return:
        """

        with open(self.logfile, "a") as f:
            f.write(f"{str(datetime.datetime.now())[:19]} {text}\n")

class RunPgm(object):
    """Class for running this program.
    """

    def __init__(self):
        """Instantiate the classes needed to run the program.
            Read the configuration file.
            Initiate values used in the run loop.

        :param
        :return:
        """

        self.cfg = configparser.ConfigParser()
        self.cfg.read("Convert.cfg")
        self.srv = Service(config=self.cfg)
        self.adj = Adjustments()
        self.dummy_competitiondate = '2011-11-11'
        self._checkconfig()

    def run(self):
        """Run the program.

        :param
        :return:
        """
        # Set the size of the command line window
        os.system(f'mode con: cols={self.window_columns} lines={self.window_lines}')

        # Check parameters
        if len(sys.argv) < 2:
            parm = 'None'
        else:
            parm = sys.argv[1]

        if parm not in ['-join', '-create', '-getstarttimes', '-readcu', '-cleanmeosbackup']:
            print('Invalid argument: ', parm)
            sys.exit(1)

        convert = Do_convert()

        # Perform the function that was requested
        if parm == '-readcu':
            convert.readcu()

        if parm == '-join':
            convert.joinfiles()

        if parm == '-getstarttimes':
            convert.getstarttimes()

        if parm == '-create':
            convert.create()

        if parm == '-cleanmeosbackup':
            convert.cleanmeosbackup()

    def _checkconfig(self):
        """Check the config file and get values from it
        """
        self.adjustments_file = self.cfg["Files"]["Adjustments"]
        self.adjustments_backup = self.cfg["Files"]["Adjustments_backup"]
        self.starttimes_eventor = self.cfg["Files"]["Starttimes_Eventor"]
        self.starttimes_corrected = self.cfg["Files"]["Starttimes_Corrected"]
        self.lastmeosbackup = self.cfg["Files"]["Last_MeOS_Backup"]
        self.lastmeosbackup_cleaned = self.cfg["Files"]["Last_MeOS_Backup_Cleaned"]
        self.sheet1name = self.cfg["Files"]["Sheet1_name"]
        self.sheet2name = self.cfg["Files"]["Sheet2_name"]
        self.punches_subdir = self.cfg["Files"]["Punches_subdir"]
        self.join_unsorted_file = self.cfg["Files"]["Join_outfile_unsorted"]
        self.join_sorted_file = self.cfg["Files"]["Join_outfile_sorted"]
        self.create_out_file = self.cfg["Files"]["Create_outfile"]
        self.window_lines = self.cfg["Window"]["Lines"]
        self.window_columns = self.cfg["Window"]["Columns"]

        turnoff = self.cfg["Actions"]["SI_turnoff"]
        self.si_turnoff = False
        if len(turnoff) > 0:
            if turnoff.upper()[0] in ('Y', 'J'):
                self.si_turnoff = True

        correct = self.cfg["Actions"]["Correct_times"]
        self.correct_times = False
        if len(correct) > 0:
            if correct.upper()[0] in ('Y', 'J'):
                self.correct_times = True

        approve = self.cfg["Actions"]["Approve_ErrA"]
        self.approve_ErrA = False
        if len(approve) > 0:
            if approve.upper()[0] in ('Y', 'J'):
                self.approve_ErrA = True


# Start main program
if __name__ == "__main__":
    rp = RunPgm()

    # Run the program and log any exception that has not been handled on a
    # lower level, end the program with return code 1 to indicate failure.
    try:
        rp.run()
    except Exception as ex:
        exceptiondata = "".join(traceback.format_exception(
            etype=type(ex),
            value=ex,
            tb=ex.__traceback__))
        rp.srv.writelog(exceptiondata)
        print(exceptiondata)
        sys.exit(1)
