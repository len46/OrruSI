#!/usr/bin/env python3
#
# OrruSI -- Orienteering result reconstruction using SportIdent
#
# Recreate a readout file from a SI Readout unit in the same format as is created
# by SIConfig+. Data is collected from all the SI units used during an
# orienteering competition.
# This program can be used when the readout from SI cards has failed for some reason.

# Lennart Almström 2021-05-01
# Version 3.1: 2025-01-13

#    Copyright (C)    2023  Lennart Almström <lennart.almstrom@telia.com>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# This program uses sireader3 modified by me from sireader and sireader2
#    Copyright (C) 2008-2014  Gaudenz Steinlin <gaudenz@durcheinandertal.ch>
#                       2014  Simon Harston <simon@harston.de>
#                       2015  Jan Vorwerk <jan.vorwerk@angexis.com>
#                       2019  Per Magnusson <per.magnusson@gmail.com>

import datetime
import time
import sys
import os
import traceback
import configparser
import shutil
import csv
import operator
import copy
import pprint

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment
import xmltodict
from sireader3 import SIReader, SIReaderException
from unicodedata import numeric

# Keys in lastmeosbackup.xml
KEYLX_meosdata = 'meosdata'
KEYLX_RunnerList = 'RunnerList'
KEYLX_Runner = 'Runner'
KEYLX_Finish = 'Finish'
KEYLX_CardNo = 'CardNo'
KEYLX_CardList = 'CardList'
KEYLX_Card = 'Card'
KEYLX_PunchList = 'PunchList'
KEYLX_Punch = 'Punch'

# Keys in startlist.xml
KEYSX_StartList = 'StartList'
KEYSX_ClassStart = 'ClassStart'
KEYSX_Class = 'Class'
KEYSX_Name = 'Name'
KEYSX_PersonStart = 'PersonStart'
KEYSX_Start = 'Start'
KEYSX_Person = 'Person'
KEYSX_Family = 'Family'
KEYSX_Given = 'Given'
KEYSX_Organisation = 'Organisation'
KEYSX_StartTime = 'StartTime'
KEYSX_ControlCard = 'ControlCard'

# Keys in courses.xml also used in coursesdata
KEYCX_CourseData = 'CourseData'
KEYCX_RaceCourseData = 'RaceCourseData'
KEYCX_Course = 'Course'
KEYCX_Name = 'Name'
KEYCX_CourseControl = 'CourseControl'
KEYCX_at_type = '@type'

# Additional keys in coursesdata added by program logic
KEYCD_Controls = 'Controls'
KEYCD_SumTimes = 'Sumtimes'
KEYCD_NbrTimes = 'Nbrtimes'
KEYCD_LegLength = 'LegLength'

# Keys used in dictionary siiddata
KEYSI_ErrAControls = 'ErrAControls'
KEYSI_ErrARows = 'ErrARows'
KEYSI_PreControls = 'PreControls'
KEYSI_PreControlRows = 'PreControlRows'
KEYSI_RaceControls = 'RaceControls'
KEYSI_RaceTimes = 'RaceTimes'
KEYSI_RaceRows = 'RaceRows'
KEYSI_CourseName = 'CourseName'

# Types of SI controls
CT_Clear = 'Clear'
CT_Check = 'Check'
CT_Start = 'Start'
CT_Finish = 'Finish'
CT_Control = 'Control'
CT_BcStart = 'BcStart'
CT_BcFinish = 'BcFinish'
CT_BcControl = 'BcControl'
CT_start_controls = CT_Start + CT_BcStart
CT_pre_controls = CT_Clear + CT_Check
CT_breaking_controls = CT_start_controls + CT_pre_controls
CT_control_controls = CT_Control + CT_BcControl
CT_finish_controls = CT_Finish + CT_BcFinish
CT_all_controls = CT_pre_controls + CT_start_controls + CT_control_controls + CT_finish_controls

# Fake SI serial number used for Start punches built from start list.
SI_FIXEDSTART_SERNBR = '999990'


class Adjustments(object):
    """Class to handle Adjustments.xlsx file.
    """

    def _set_alignment(self, afs):
        """Internal procedure to set alignments.

        :param: afs: Sheet object
        :return:
        """
        afs['B1'].alignment = Alignment(horizontal='right')
        afs['D1'].alignment = Alignment(horizontal='right')
        afs['F1'].alignment = Alignment(horizontal='right')
        afs['G1'].alignment = Alignment(horizontal='right')
        afs['H1'].alignment = Alignment(horizontal='right')
        afs['K1'].alignment = Alignment(horizontal='right')

    def create_new_adjustments_file(self):
        """Create and initialize Adjustments.xlsx.

        :param
        :return:
        """
        if os.path.exists(rp.adjustments_file):
            try:
                os.remove(rp.adjustments_file)
            except PermissionError as msg:
                rp.srv.print(f'{rp.adjustments_file} not accessible. '
                             f'Open in other program?\n'
                             f'Close the other program and restart this program.')
                sys.exit(1)

        af = Workbook()
        afs = af.active
        afs.title = rp.sheet1name
        headers = ('Filename', 'Control', 'Mode', 'Serial', 'Time error', 'Voltage',
                   'Active time', 'Capacity', 'Firmware', 'Battery date', 'Battery %',
                   'Build date', 'Modification date', 'Last punch date')

        afs.append(headers)
        afs.column_dimensions['A'].width = 18
        afs.column_dimensions['B'].width = 8
        afs.column_dimensions['C'].width = 20
        afs.column_dimensions['D'].width = 8
        afs.column_dimensions['E'].width = 15
        afs.column_dimensions['F'].width = 8
        afs.column_dimensions['G'].width = 12
        afs.column_dimensions['H'].width = 10
        afs.column_dimensions['I'].width = 10
        afs.column_dimensions['J'].width = 13
        afs.column_dimensions['K'].width = 10
        afs.column_dimensions['L'].width = 12
        afs.column_dimensions['M'].width = 20
        afs.column_dimensions['N'].width = 20
        self._set_alignment(afs)
        afr = af.create_sheet(rp.sheet2name)
        headers = ('Race', 'From', 'To')
        afr.append(headers)
        row1 = ('- dates', rp.dummy_racedate, rp.dummy_racedate)
        afr.append(row1)
        row2 = ('- times', '00:00:00', '23:59:59')
        afr.append(row2)
        afr.column_dimensions['A'].width = 12
        afr.column_dimensions['B'].width = 12
        afr.column_dimensions['C'].width = 12
        af.save(filename=rp.adjustments_file)
        shutil.copy2(rp.adjustments_file, rp.adjustments_backup)

    def read_adjustments_file(self):
        """Read all data from Adjustments.xlsx.

        :param
        :return: Tuple:
                 af: workbook object
                 afs: statistics sheet object
                 afsdata: list of lists containing data in statistics sheet
                 afr: Race_dates_times sheet object
                 afrdata: list of lists containing data in Race_dates_times sheet
        """
        if not os.path.exists(rp.adjustments_file):
            rp.srv.print(f'{rp.adjustments_file} does not exist')
            sys.exit(1)

        af = load_workbook(filename=rp.adjustments_file)
        afs = af[rp.sheet1name]
        afr = af[rp.sheet2name]

        # Empty outer list
        afsdata = []
        # Read only the first 14 columns
        for row in afs.iter_rows(min_row=1, min_col=1, max_row=afs.max_row, max_col=14):
            rowdata = []
            # Read rows and change None values to empty string
            rowempty = True
            for cell in row:
                if not cell.value in (None, ''):
                    rowempty = False
                rowdata.append('' if cell.value == None else cell.value)
            if not rowempty:
                afsdata.append(rowdata)

        # Empty outer list
        afrdata = []
        # Read only the first three columns and the first three rows
        for row in afr.iter_rows(min_row=1, min_col=1, max_row=3, max_col=3):
            rowdata = []
            # Read rows and change None values to empty string
            rowempty = True
            for cell in row:
                if not cell.value in (None, ''):
                    rowempty = False
                rowdata.append('' if cell.value == None else cell.value)
            if not rowempty:
                afrdata.append(rowdata)

        return af, afs, afsdata, afr, afrdata

    def write_adjustments_file(self, af, afs, afsdata, afr, afrdata):
        """Replace all data in Adjustments.xlsx.

        :param: af: workbook object
                afs: statistics sheet object
                afsdata: list of lists containing data in statistics sheet
                afr: Race_dates_times sheet object
                afrdata: list of lists containing data in Race_dates_times sheet

        :return:
        """
        afs.delete_rows(1, afs.max_row)
        afr.delete_rows(1, afr.max_row)

        for row in afsdata:
            afs.append(row)

        for row in afrdata:
            afr.append(row)

        self._set_alignment(afs)

        try:
            af.save(filename=rp.adjustments_file)
            shutil.copy2(rp.adjustments_file, rp.adjustments_backup)
        except PermissionError as msg:
            rp.srv.print(f'{rp.adjustments_file} or {rp.adjustments_backup} '
                         f'not accessible. Open in other program?\n'
                         f'Close the other program and reread this SI station '
                         f'to update {rp.adjustments_file}.')
            sys.exit(1)

    def update_adjustments(self, af, afs, arg_afsdata, afr, afrdata, csvfilename, newctldata):
        """Replace or add a row of data in afdata and rewrite the xlsx file.

        :param: af: workbook object
                afs: statistics sheet object
                afsdata: list of lists containing data in statistics sheet
                afr: Race_dates_times sheet object
                afrdata: list of lists containing data in Race_dates_times sheet
                csvfilename: filename of file containing punches
                newctldata: list containing new data to be added or replaced:
                    ctlnbr: Control number for control
                    ctlmode: type of control
                    ctlserialnbr: Serial number for control
                    timediff_str: string containing time error in format +-hh:mm:ss.ttt
                    ctlvoltage: battery voltage of control
                    ctlactivetime: active time of control
                    ctlbatcap: battery capacity of control
                    ctlvoltage: battery voltage of control
                    ctlfirmware: firmware level of control
                    ctlbatterydate: battery date of control
                    ctlbatleft: percent remaining battery capacity of control
                    ctlbuilddate: build date of control
                    ctllastmodifdate: last modification date and time of control
                    ctllastpunchdate: last punch date and time of control

        :return: afsdata (updated), afrdata
        """
        # Make a copy of afsdata, as it will be modified.
        afsdata = copy.deepcopy(arg_afsdata)
        row_updated = False

        # Build the new data row for statistics sheet
        newrow = [csvfilename] + newctldata
        # Search for the row to be replaced and replace it if found
        for rownbr in range(1, len(afsdata)):
            if afsdata[rownbr][0] == csvfilename:
                afsdata[rownbr] = newrow
                row_updated = True
        # If row not found, add a new row
        if not row_updated:
            afsdata.append(newrow)

        # Write to excel file
        rp.adj.write_adjustments_file(af, afs, afsdata, afr, afrdata)
        return afsdata, afrdata

class Do_reconstruction():
    """Class to do conversion work.
    """

    def readcu(self):
        """Read punch data from SI control units and update excel file with data from punch files.

        :param:

        :return:
        """

        def _callsi(method):
            """Internal method to issue a simple call without parameters to SIReader
               and handle errors from the call.

            :param:

            :return: True/False to indicate success or not of call to SIReader
                     Value returned by SIReader
            """
            ok = False
            errmsg = ''
            for ii in range(0, maxretries):
                try:
                    datavalue = method()
                    ok = True
                    break;
                except SIReaderException as msg:
                    errmsg = msg
                    time.sleep(0.5)
            if not ok:
                rp.srv.print(f'ERROR: Failed to talk to the station '
                             f'({method.__name__}\n)'
                             f'  {errmsg}\n'
                             'Maybe the station is not connected or not awake?\n'
                             'Try to disconnect and reconnect the USB cable '
                             'to the computer\n'
                             'and/or lift the control unit from the readout unit '
                             'and put it down again.\n'
                             'If that does not help, press q and restart '
                             'this program.')
                return False, None
            return True, datavalue

        # This is the start of code for readcu

        # If this is first run for this competition,
        # create and initialize the excel file
        # and remove old punch files if there are any
        if rp.srv.user_positive('Is this the first control unit '
                                   'read session for this competition?'):
            rp.adj.create_new_adjustments_file()
            punchfiles = (os.listdir(rp.punches_subdir))
            for filename in punchfiles:
                os.remove(rp.punches_subdir + '\\' + filename)

        # Read in all data from the excel file
        af, afs, afsdata, afr, afrdata = rp.adj.read_adjustments_file()

        # Connect to the SI Readout station
        try:
                # Find serial port automatically
            si = SIReader(debug=False)
            rp.srv.print('Connected to station on port ' + si.port)
        except:
            rp.srv.print('Failed to connect to an SI station on any '
                         'of the available serial ports.')
            sys.exit()

        # Set station in remote mode
        ok = False
        errmsg = ''
        for ii in range(0, 3):
            try:
                si.set_remote()
                ok = True
                break;
            except SIReaderException as msg:
                errmsg = msg
                time.sleep(0.5)
        if not ok:
            rp.srv.print(f'ERROR: Failed to set station in remote mode: {errmsg}')
            sys.exit()

        # Read backup data from SI station when user presses Enter
        rp.srv.print('Ready to read backup memory of SI station.')
        maxretries = 5
        while True:
            answer = rp.srv.ask_user(msg='Press <Enter> to read next remote station, '
                                         'or q to quit.')
            if answer == 'q':
                break
            elif answer == '':
                if si.direct:
                    si.set_remote()
            else:
                rp.srv.print('Unrecognized input')
                continue

            valueok, dummy = _callsi(si._update_proto_config)
            if not valueok:
                continue

            readbackup = True
            if not si.proto_config['mode'] in si.SUPPORTED_READ_BACKUP_MODES:
                readbackup = False

            # Find out the time error of this SI station.
            # Get the wall clock both before and after reading the SI station time
            # and take the mean value of the wall clock readings.
            wallclocktime1 = datetime.datetime.now()
            # Get the SI station time.
            valueok, stationtime = _callsi(si.get_time)
            if not valueok:
                continue

            wallclocktime2 = datetime.datetime.now()
            wallclocktime = wallclocktime1 + ((wallclocktime2 - wallclocktime1) / 2)
            # Make the time difference positive and remember the correct plus/minus sign.
            if wallclocktime > stationtime:
                diffsign = '-'
                timediff = wallclocktime - stationtime
            else:
                diffsign = '+'
                timediff = stationtime - wallclocktime
            timediff_str = str(timediff)
            # If the time difference has a millisecond part, make it consist of exactly three decimals
            parts = timediff_str.split('.')
            if len(parts) == 2:
                parts[1] = (parts[1] + '000')[:3]
                timediff_str = '.'.join(parts)
            # Remove zero parts from the beginning of the time difference string
            newtimediff_str = timediff_str
            for char in timediff_str:
                if char in ('0', ':'):
                    newtimediff_str = newtimediff_str[1:]
                else:
                    break
            # Finally add a zero if everything was removed from the integer part (just to make it look better)
            if newtimediff_str[0] == '.':
                newtimediff_str = f'0{newtimediff_str}'
            timediff_str = newtimediff_str

            # Get the active time of the control
            valueok, ctlactivetime = _callsi(si.sysval_active_time)
            if not valueok:
                continue

            # Get the battery capacity of the control
            valueok, ctlbatcap_float = _callsi(si.sysval_battery_capacity)
            if not valueok:
                continue

            ctlbatcap = round(ctlbatcap_float, 0)

            # Get the firmware level of the control
            valueok, ctlfirmware = _callsi(si.sysval_fwver)
            if not valueok:
                continue

            # Get the battery date of the control
            valueok, ctlbatterydate = _callsi(si.sysval_battery_date)
            if not valueok:
                continue

            # Get the battery used percent of the control and make it battery left percent
            valueok, ctlbatused_float = _callsi(si.sysval_used_battery)
            if not valueok:
                continue

            ctlbatleft = round(100.0 - ctlbatused_float, 0)

            # Get the build date of the control
            valueok, ctlbuilddate = _callsi(si.sysval_build_date)
            if not valueok:
                continue

            # Get the last modification date of the control
            valueok, ctllastmodifdate_datetime = _callsi(si.sysval_lastmodif_datetime)
            if not valueok:
                continue
            ctllastmodifdate = str(ctllastmodifdate_datetime)[:19]

            # Get the battery voltage of the control
            valueok, ctlvoltage_float = _callsi(si.sysval_volt)
            if not valueok:
                continue

            ctlvoltage = round(ctlvoltage_float, 2)

            # Build the filename for the punches file
            ctlnbr = si._station_code
            ctlserialnbr = si._serno
            ctlmode = si.sysval_mode_str()
            if ctlmode[0:4] == 'SIAC':
                ctlnbr = 0
            ctlmode4 = ctlmode[:4].replace(' ', '_')
            csvfilename = f'{ctlmode4}{str(ctlnbr)}_{str(ctlserialnbr)}.csv'

            ctllastpunchdate = ''
            backup = []
            if readbackup:
                # Read the backup memory from the SI station
                for ii in range(0, maxretries):
                    try:
                        rp.srv.print(f'Trying to read backup memory '
                                     f'of station: {str(ctlnbr)} ')
                        sys.stdout.flush()
                        backup = si.read_backup(progress=1)
                        ok = True
                        break
                    except SIReaderException as msg:
                        rp.srv.print('')
                        time.sleep(0.5)
                        errmsg = msg
                    if not ok:
                        rp.srv.print(f'ERROR: Failed to talk to the station '
                                     f'(read_backup)\n)'
                                     f'  {errmsg}\n'
                                     'Maybe the station is not connected or not awake?\n'
                                     'Try to disconnect and reconnect the USB cable '
                                     'to the computer\n'
                                     'and/or lift the control unit from the readout unit '
                                     'and put it down again.\n'
                                     'If that does not help, press q and restart '
                                     'this program.')
                        continue

                # If this is the first SI station that has punches, use the date of the last punch
                # as race date.
                if len(backup) > 0 \
                        and afrdata[1][1] == rp.dummy_racedate:
                    # Get first 10 positions (= punch date) from the first column in the last row
                    # and set it as both first and last competition date.
                    afrdata[1][1] = str(backup[-1][0])[:10]
                    afrdata[1][2] = afrdata[1][1]

                # Remember the last punch time on this control
                if len(backup) > 0:
                    # Get date and time from the first column in the last row
                    ctllastpunchdate = str(backup[-1][0])[:11] + str(backup[-1][0])[11:19]



            # Create a new punch file in Punches subdirectory
            csvpathfilename = rp.punches_subdir + '\\' + csvfilename
            if readbackup:
                csvpathfilename = si.write_backup_csv(backup,filename=csvpathfilename,
                                                      include_serno=True)
                rp.srv.print(f'{csvpathfilename} was created, '
                             f'number of punches is {len(backup)}.')
                if len(backup) == 0:
                    rp.srv.print(f'No punches were read from this unit.\n'
                                 f'If it was used, please read it once more.')
            else:
                rp.srv.print(f'{csvpathfilename} not created because this '
                             f'control type does not have punches')

            # Update or add data for this file to the excel file
            ctldata = [ctlnbr, ctlmode, ctlserialnbr, timediff_str, ctlvoltage,
                       ctlactivetime, ctlbatcap, ctlfirmware, ctlbatterydate,
                       ctlbatleft, ctlbuilddate, ctllastmodifdate, ctllastpunchdate]
            afsdata, afrdata = rp.adj.update_adjustments(af, afs, afsdata, afr, afrdata,
                                               csvfilename, ctldata)

            # Turn off the SI station if so is requested, else let it beep only
            if rp.si_turnoff:
                valueok, dummy = _callsi(si.poweroff)
                if not valueok:
                    continue
            else:
                valueok, dummy = _callsi(si.beep)
                if not valueok:
                    continue


    def joinfiles(self):
        """Read all the collected punch files, adjust punching times and create
            a file containing all punches ordered by partipicant and punch timedata from SI control units.

        :param:

        :return:
        """

        def _is_float(string):
            """Internal method to check if a string contains a float number.

            :param: string: string to be tested

            :return: True or False
            """
            try:
                float(string)
                return True
            except ValueError:
                return False

        # Check if time corrections should be used
        # (only check with user if config file specifies correction)
        do_correct_times = False
        if rp.do_correct_times:
            if rp.srv.user_positive(f'Should time corrections in '
                                       f'{rp.adjustments_file} be applid?'):
                do_correct_times = True

        # Get data from the excel file
        af, afs, afsdata, afr, afrdata = rp.adj.read_adjustments_file()
        rp.srv.print(f'The Excel file {rp.adjustments_file} contains '
                     f'the following information:')
        LAYOUT = "{!s:18} {!s:8} {!s:20} {!s:8} {!s:15} {!s:8} {!s:12} {!s:10} " \
                 "{!s:10} {!s:13} {!s:10} {!s:12} {!s:20} {!s:20}"
        for line in afsdata:
            rp.srv.print(LAYOUT.format(*line))
        rp.srv.print('')
        LAYOUT = "{!s:12} {!s:12} {!s:12}"
        for line in afrdata:
            rp.srv.print(LAYOUT.format(*line))
        rp.srv.print('')
        if not rp.srv.user_positive(f'Is this the correct file?'):
            sys.exit(1)

        # Check if ErrA punches should be approved
        approve_ErrA = False
        if rp.approve_ErrA:
            approve_ErrA = True

        # Get race dates and times from excel file. If the user has changed them, they might have become
        # datetime values, so make them strings again.
        valid, racedatefrom = rp.srv.validate_date(afrdata[1][1])
        if not valid:
            rp.srv.print(f'Date "{racedatefrom}" in cell B2 is not '
                         f'in correct date format')
            sys.exit(1)
        valid, racedateto = rp.srv.validate_date(afrdata[1][2])
        if not valid:
            rp.srv.print(f'Date "{racedateto}" in cell B3 is not in '
                         f'correct date format')
            sys.exit(1)
        valid, racetimefrom = rp.srv.validate_time(afrdata[2][1])
        if not valid:
            rp.srv.print(f'Time "{racetimefrom}" in cell B3 is not '
                         f'in correct time format')
            sys.exit(1)
        valid, racetimeto = rp.srv.validate_time(afrdata[2][2])
        if not valid:
            rp.srv.print(f'Time "{racetimeto}" in cell C3 is not in correct time format')
            sys.exit(1)


        racedatetimes = (racedatefrom + '   ' + racetimefrom,
                            racedateto + '   ' + racetimeto)

        # Make the error specification from excel data. Some error checking is done if it has
        # been modified or built by the user.
        # The error specification is a list of lists containing all time errors to be corrected.
        errorspecs = []
        for rownbr in range(1,len(afsdata)):
            headers = ('Filename', 'Control', 'Mode', 'Serial', 'Time error', 'Voltage',
                       'Active time', 'Capacity', 'Firmware', 'Battery date', 'Battery %',
                       'Build date', 'Modification date', 'Last punch date')

            # Split the current row of data from the excel file
            curfilename, curctlnbr, curmode, curserialnbr, curerror = afsdata[rownbr][:5]
            # Check the error spec and set internal control numbers
            # for Start, Finish, Clear, and Check units.
            if curerror == '':
                curerror = '0'
            if curerror[0] not in ('+', '-'):
                curerror = '+' + curerror
            if curmode in CT_start_controls:
                curctlnbr = -1
            elif curmode in CT_finish_controls:
                curctlnbr = -2
            elif curmode == CT_Clear:
                curctlnbr = -3
            elif curmode == CT_Check:
                curctlnbr = -4
            elif curmode in CT_control_controls:
                if not str(curctlnbr).isnumeric():
                    rp.srv.print(f'Control number {curctlnbr} on line {rownbr} in ' \
                                 f'{rp.adjustments_file} is not numeric')
                    sys.exit(1)
                curctlnbr_num = int(curctlnbr)
                if curctlnbr_num < 31 \
                    or curctlnbr_num > 511:
                    rp.srv.print(f'Control {curctlnbr} on line {rownbr}' \
                                 f' of {rp.adjustments_file} must be in range 31 - 511')
                    sys.exit(1)

            if curerror[0] not in('+', '-'):
                rp.srv.print(f'Error correction time on line {rownbr}' \
                      f' of {rp.adjustments_file} must start with + or -')
                sys.exit(1)
            curerrparts = curerror[1:].split(':')
            errsecs = 0
            for part in curerrparts:
                if not _is_float(part):
                    rp.srv.print(f'Error correction time on line {rownbr}' \
                                 f' of {rp.adjustments_file} contains '
                                 f'an unnumeric part')
                    sys.exit(1)
                errsecs = 60 * errsecs + float(part)
            if curerror[0] == '-':
                errsecs = - errsecs
            if curfilename.strip() != '':
                if curfilename[-4:] != '.csv':
                    rp.srv.print(f'Filename on line {rownbr}'
                                 f' of {rp.adjustments_file} must end in .csv')

            # Add this row to the error specification
            errorspecs.append([curctlnbr, curserialnbr, errsecs, curfilename])

        # Error specification has been built.

        # Check if there is a start times excel file
        fixedstarttimes = False
        # Initiate empty dictionary to contain key = siid and data = start time
        fixstartdata = {}
        if os.path.exists(rp.starttimes_corrected):
            fixedstarttimes = True
            # Read the excel file.
            fixstart = load_workbook(filename=rp.starttimes_corrected)
            fixstarts = fixstart.active

            # Read only the first 3 columns and skip the first row containing headers.
            for row in fixstarts.iter_rows(min_row=2, min_col=1, max_row=fixstarts.max_row, max_col=3):
                rowdata = []
                # Read rows and change None values to empty string
                rowempty = True
                for cell in row:
                    if not cell.value in (None, ''):
                        rowempty = False
                    rowdata.append('' if cell.value == None else cell.value)
                # Create a dictionary entry and make sure the siid is a string as it is a string in our input file
                # from join_files. Also insure that the time is a string in case it has been modified manually
                # in the excel file.
                if not rowempty:
                    siid = str(rowdata[0])
                    date = rowdata[1]
                    time = rowdata[2]
                    if not siid.isdigit():
                        rp.srv.print(f'Sportident id {siid} ' 
                                     f'in {rp.starttimes_corrected} is '
                                     f'not numeric')
                        exit(1)
                    valid, datestr = rp.srv.validate_date(date)
                    if not valid:
                        rp.srv.print(f'Date {datestr} for Sportident id {siid} '
                                     f'in {rp.starttimes_corrected} is not '
                                     f'a valid date')
                        exit(1)
                    valid, timestr = rp.srv.validate_time(time)
                    if not valid:
                        print(f'Time {timestr} for Sportident id {siid} '
                              f'in {rp.starttimes_corrected} is not a valid time')
                        exit(1)
                    timestr = timestr + '.000'

                    datedt = datetime.datetime.strptime(datestr, '%Y-%m-%d')
                    weekdayname = datetime.datetime.strftime(datedt, '%A')[:2]

                    fixstartdata[siid] = [datestr, timestr, weekdayname]

        # Now read all the punch files and apply the time corrections.
        nbrinfiles = 0
        headerline = 'X'

        # Get the names of the punch files
        punchfiles = (os.listdir(rp.punches_subdir))
        punchfiles.sort()

        # Collect all the punches

        # Handle each punch file
        datain_unsorted = []
        for filename in punchfiles:
            # Handle only .csv files (ignoring other file types)
            ext = os.path.splitext(filename)
            if ext[1] == '.csv':
                nbrinfiles += 1
                # Open the punch file
                with open(rp.punches_subdir + '\\' + filename) as infile:
                    infilelines = 0
                    # Read each line
                    for infileline in infile:
                        infilelines += 1
                        # Save the header from the first punch file to reuse it in the output file
                        if nbrinfiles == 1 and infilelines == 1:
                            headerline = infileline
                        # Ignore all header lines
                        if infilelines > 1 and infileline != '':
                            # Apply each error specification line to each punch file line.
                            # If they do not match, the correction will be ignored.
                            for errorspec in errorspecs:
                                infileline = self._correct(infileline, racedatetimes,
                                                           errorspec, filename,
                                                           do_correct_times, approve_ErrA,
                                                           fixedstarttimes, fixstartdata)
                                # If any of the error specs tells us to ignore this file line, do not
                                # try any more error specs for this file line.
                                if infileline == '':
                                    break
                            # If the _correct method tells us to ignore this line, do it,
                            # otherwise write the line to the unsorted intermittent file.
                            if infileline != '':
                                datain_unsorted.append(infileline)

        # If there is a start times file, build start punches for the fixed start times.
        # Generated Start punches for runners that do not start will be removed by the
        # logic in _errA_punchtimes, as they are the only punches for that runner.
        # (Runners with only one punch are always removed.)
        if fixedstarttimes:
            punchnbr = 0
            readtime = str(datetime.datetime.now())[:19]
            for siidkey, startdata in fixstartdata.items():
                startdate, starttime, weekdayname = startdata
                startline = 18 * ['']
                startline[-1] = '\n'
                punchnbr += 1
                startline[0] = str(punchnbr)
                startline[1] = readtime
                startline[2] = siidkey
                startline[3] = startdate + '   ' + starttime
                startline[5] = SI_FIXEDSTART_SERNBR
                startline[6] = '1'
                startline[7] = weekdayname
                startline[8] = starttime
                startline[9] = CT_Start
                startline[10] = '0'
                startline[11] = '1'
                infileline = ';'.join(startline)
                datain_unsorted.append(infileline)

        # Open the output file and write all the punches
        nbroutlines = 0
        with open(rp.join_unsorted_file, 'w') as outfile:
            for line in datain_unsorted:
                nbroutlines += 1
                outfile.write(line)

        rp.srv.print(f'{nbrinfiles} csv files read, {nbroutlines} lines '
                     f'written to {rp.join_unsorted_file}')

        # Read the unsorted file and collect all its data in "datain_unsorted".
        datain_unsorted = []
        inrownbr = 0
        with open(rp.join_unsorted_file) as csv_file:
            csvreader = csv.reader(csv_file, delimiter=';')

            for row in csvreader:
                inrownbr += 1
                datain_unsorted.append(row)

        # Sort the datain_unsorted on SIID (column 3) and corrected punch time (column 9)
        # datain_sorted = sorted(datain_unsorted, key=operator.itemgetter(2, 8))

        # Postprocess the file to remove orphan ErrA punches. They signify punches where
        # the control unit has not been able to get the correct siid from the SI card.
        # Also, if there is a file courses.xml containing the courses for the race, try to interpolate a punch time
        # for the ErrA punches. Also see further information in the errA_punchtimes header.
        newdatain = self._errA_punchtimes(datain_unsorted, approve_ErrA)
        datain = newdatain

        # Open the file to contain the sorted data
        with open(rp.join_sorted_file, mode='w', newline='') as outfile:
            # Get a csv writer object
            outfile_writer = csv.writer(outfile, delimiter=';', quotechar="'", quoting=csv.QUOTE_MINIMAL)
            # Remove the last semicolon in header
            headerline = headerline[:-1]
            # First write the saved header line after splitting it (as the csv writer needs a list)
            headerline_split = headerline.split(';')
            outfile_writer.writerow(headerline_split)
            # Then write all the sorted rows.
            for row in datain:
                outfile_writer.writerow(row)

        rp.srv.print(f'{rp.join_unsorted_file} has been sorted '
                     f'into {rp.join_sorted_file}')

    def _correct(self, arg_fileline, racedatetimes,
                 errorspec, filename,
                 do_correct_times, approve_ErrA,
                 fixedstarttimes, fixstartdata):
        """Internal method to correct the punch time of one punch. It also checks if the punch
            has been done on the competition date, otherwise the punch is ignored.

        :param: fileline: tuple containing the values from one punch reading
                racedate: tuple containing correct competition dates from and to
                errorspec: tuple containing the proper row data from the excel file
                filename: name of the punches file
                do_correct_times: if True, do time corrections
                approve_ErrA: if True, approve punches marked ErrA

        :return: fileline containing corrected data, or empty string if this punch
                 should be ignored because of wrong date.
        """
        # Make a copy of fileline, as it will be modified.
        fileline = copy.deepcopy(arg_fileline)

        # Split data from excel file row.
        # Note that the correction time is provided in seconds with 3 decimals.
        ctlnbr, ctlserialnbr, errsecs, correctfilename = errorspec

        # Make a list of the punch file data line
        filedata = fileline.split(';')

        # If millisecond part of punch time is missing, add three zeroes
        # to both fields containing punch time
        if len(filedata[3]) == 21:
            filedata[3] += '.000'
        if len(filedata[8]) == 8:
            filedata[8] += '.000'

        # Use while True only to be able to break
        while True:
            # Prepare updated punch file line in case we break without changes
            newfileline = ';'.join(filedata)

            # If the SI station reports that an error has occured at punch time,
            # do no more correction of the data.
            #
            # If it is an ErrA and if they should be approved, keep it
            # if the date is in the range valid for the date,
            # otherwise remove it.
            # Other Errx errors are always removed.
            if filedata[3][13:16] == 'Err':
                if filedata[3][13:17] == 'ErrA':
                    if not approve_ErrA:
                        newfileline = ''
                    errAdate = filedata[3][:10]
                    if errAdate < racedatetimes[0][:10] \
                       or errAdate > racedatetimes[1][:10]:
                        newfileline = ''
                    break
                else:
                    newfileline = ''
                    break

            # If this is not an interesting type of contol, don't correct
            if filedata[9] not in CT_all_controls:
                break
            # If this is not the proper control number to correct, don't correct
            if filedata[9] in CT_control_controls and int(filedata[6]) != ctlnbr:
                break
            # Control number for a Start unit, has internally in this program been set to -1
            # to recognize it. If this is not a Start unit, don't correct
            if filedata[9] in CT_start_controls and ctlnbr != -1:
                break
            # Same for a Finish unit
            if filedata[9] in CT_finish_controls and ctlnbr != -2:
                break
            # Same for a Clear unit
            if filedata[9] == CT_Clear and ctlnbr != -3:
                break
            # Same for a Check unit
            if filedata[9] == CT_Check and ctlnbr != -4:
                break
            # If a punch file name has been registered in the excel file, check that this
            # punch comes from that punch file. If not, don't correct.
            if correctfilename.strip() != '':
                if filename != correctfilename:
                    break

            # If this is a start control punch, check if there is a fixed start time
            # for this runner. In that case, remove this start punch.
            if filedata[9] in CT_start_controls and ctlnbr == -1:
                if fixedstarttimes:
                    if filedata[2] in fixstartdata:
                        rp.srv.print(f'Sportident id {filedata[2]} has a Start punch '
                                     f'and also an allocated start time. '
                                     f'The Start punch has been removed.')
                        newfileline = ''
                        break

            # We have passed all the tests except the correct date test. That can only
            # be tested when we have corrected the punch time.

            # Correct the punch time according to the time correction in the excel file
            datetimetocorrect = filedata[3]
            # If time corrections should not be applied, we already have a correct date
            if not do_correct_times:
                correcteddatetime = datetimetocorrect
                correcteddate = datetimetocorrect[:10]
            # Otherwise correct the datetime
            else:
                datetimetocorrect_dt = datetime.datetime.strptime(datetimetocorrect,
                                                                  '%Y-%m-%d   %H:%M:%S.%f')
                correcteddatetime_dt = datetimetocorrect_dt - datetime.timedelta(seconds=errsecs)
                correcteddatetime = datetime.datetime.strftime(correcteddatetime_dt,
                                                               '%Y-%m-%d   %H:%M:%S.%f')[:25]
                correcteddate = correcteddatetime[:10]

                # Replace the punch date and time in the punch file data line
                filedata[3] = correcteddatetime
                filedata[8] = correcteddatetime[13:]

                # Here are some code lines to print the correction if needed for debugging
                if rp.debug:
                    rp.srv.print(f'{correcteddate} {racedatetimes[0]} {racedatetimes[1]}')
                    if ctlnbr == -1:
                        ctlname = 'Start'
                    elif ctlnbr == -2:
                        ctlname = 'Finish'
                    elif ctlnbr == -3:
                        ctlname = 'Clear'
                    elif ctlnbr == -4:
                        ctlname = 'Check'
                    else:
                        ctlname = str(ctlnbr)
                    rp.srv.print(f'Control {ctlname}, file {filename} corrected '
                                 f'from {datetimetocorrect} to {correcteddatetime}')

            # If punch is outside valid race time, ignore it
            if correcteddatetime < racedatetimes[0] + '.000' \
               or correcteddatetime > racedatetimes[1] + '.999':
                newfileline = ''
                break

            # Make the row semicolon separated
            newfileline = ';'.join(filedata)
            break

        return newfileline

    def _errA_punchtimes(self, datain_unsorted, approve_errA):
        """This is a subfunction of joinfiles.
        If ErrA are to be approved, postprocess the file to remove orphan ErrA punches.
        They signify punches where the control unit has not been able to get the
        correct siid from the SI card.
        Also, if there is a file courses.xml containing the courses for the race, try to interpolate a punch time
        for the ErrA punches.
        As a side effect, remove runners having only pre-control punches (Clear and/or Check) and runners
        without both Start and Finish punches (they are considered to be from setting out the controls).
        Because of the side effects above, this function is always called. If errA punches are not to be approved,
        they have already been removed by the logic in joinfiles.

        Structures used by errA_punchtimes:

        controlerrAdata: Dictionary containing punch times before and after errA punches.
        - Key: Unique punch id
        - Data: List with 3 items:
                - datetime of punch before sequence of errA punches
                - datetime of punch after sequence of errA punches
                - seconds between after and before punch

        courses: Dictionary containing data about courses.
        - Key: Course name
        - Data: Dictionary with keys describing type of course data:
                Key 'Controls':
                    Data: List of controls for this course
                Key 'Leglength':
                    Data: List of leg lengths for the leg to each control.
                          The first leg length is 0, it is the length to the Start control.
                Key: 'Nbrtimes':
                    Data: Number of runners who have contributed to 'Sumtimes' below.
                Key: 'Sumtimes':
                    Data: List containing total number of seconds the contributing runners
                          have spent from previous control to the control according to
                          'Controls' above. The first value is 0 as it represents the time
                          to the Start control.

        siiddata: Dictionary containing collected data about each sportident id (siid) that
                  has been used in the race.
        - Key: siid
        - Data: Dictionary with keys describing type of data about this siid:
                Key 'Coursename':
                    Data: Name of course used or None if it can not be determined.
                Key 'ErrAControls':
                    Data: List of control numbers that have had ErrA punches.
                Key 'ErrARows':
                    Data: List, each item containing a list of the punch data for
                          each ErrA punch.
                          These items will be changed to contain valid punch times
                          if interpolation of punch times for the ErrA punches is
                          successful.
                Key 'PreControlRows':
                    Data: List, each item containing a list of the punch data for
                          each punch before the Start punch (or built Start punch
                          if start times have been allocated).
                Key 'PreControls':
                    Data: List of control names (normally Clear, Check) of punches
                          before the Start punch.
                Key 'RaceControls':
                    Data: List of controls that the runner has actually punched
                          without ErrA errors.
                Key 'RaceRows':
                    Data: List, each item containing a list of the punch data for
                          each punch corresponing to 'RaceControls' above.
                Key 'RaceTimes':
                    Data: List, each item containing the date and time that the
                          runner has punched the control corresponing to
                          'RaceControls' above.
                If there are extra punches that do not invalidate the race, these
                extra punches will be removed from 'RaceControls', 'RaceRows' and
                'RaceTimes' during the interpolation process for Erra punches.

        :param: datain_unsorted: List containing the data of all collected punches.
                They might have been updated with start times from Eventor
                and had their punch times corrected.
                approve_ErrA: if True, approve punches marked ErrA

        :return: Corrected datain as described above.
        """
        # Count ErrA punches, total and handled.
        nbr_ErrA = 0
        nbr_ErrA_interpolated = 0

        # Check if a courses.xml file with course data has been provided.
        courses = None
        coursesxml_exists = False
        if approve_errA:
            if os.path.exists(rp.courses_xml):
                coursesxml_exists = True
                rp.srv.print(f'File {rp.courses_xml} exists. '
                             f'ErrA punch times will be interpolated if possible.')

                # Read the file
                with open(rp.courses_xml, 'r', encoding='utf-8') as file:
                    xmldata = file.read()
                coursesdata = xmltodict.parse(xmldata)

                courses = {}
                for course in coursesdata[KEYCX_CourseData][KEYCX_RaceCourseData][KEYCX_Course]:
                    coursename = course[KEYCX_Name]
                    controls = []
                    leglengths = []
                    for control in course[KEYCX_CourseControl]:
                        if control[KEYCX_at_type] == CT_Start:
                            controls.append(CT_Start)
                        if control[KEYCX_at_type] == CT_Control:
                            controls.append(control[CT_Control])
                        if control[KEYCX_at_type] == CT_Finish:
                            controls.append(CT_Finish)
                        leglengths.append(control.get(KEYCD_LegLength, 0))
                    courses[coursename] = {KEYCD_Controls: controls}

                    courses[coursename].update({KEYCD_LegLength: leglengths})

                if rp.debug:
                    rp.srv.print('Courses:')
                    rp.srv.print(pprint.pformat(courses,
                                                compact=True, width=120))

        # If serial number is not included with the punch line,
        # give it a fake serial number and give each punch line a new
        # unique serial number.
        fake_serno = 1000
        olddt = ''
        oldlinenbr = 99999
        for newlinenbr, line in enumerate(datain_unsorted):
            curlinenbr = int(line[0])
            curserno = line[5]
            if curlinenbr <= oldlinenbr:
                if curserno == '':
                    fake_serno += 1
            if curserno == '':
                line[5] = str(fake_serno)
            line[0] = str(newlinenbr + 1)
            oldlinenbr = curlinenbr
            datain_unsorted[newlinenbr] = line

        if rp.debug:
            with open("datainunsortedpretty.txt", "w") as log_file:
                pprint.pprint(datain_unsorted, log_file,
                              compact=True, width=120)

        # Sort the datain_unsorted on SIID (column 3) and corrected punch time (column 4)
        # to create datain.
        def makekey(list):
            """The inner function makekey is used by the "sorted" call below to change
            an ErrA text in the punch datetime to +rrA to make that line collate
            before lines with a real time, so that all ErrA lines come before all
            lines with a real time (+ collates before numbers, E collates after).
            This is required by the logic later in this method.
            Note that the sorted record is not changed, only the key used during the sort.
            """
            key1 = list[2]
            key2 = list[3]
            if key2[13:17] == 'ErrA':
                newkey2 = key2[:13] + '+' + key2[14:]
                key2 = newkey2
            return key1 + key2

        datain = sorted(datain_unsorted, key=makekey)
        # datain = sorted(datain_unsorted, key=operator.itemgetter(2, 3))

        if rp.debug:
            with open("datainpretty.txt", "w") as log_file:
                pprint.pprint(datain, log_file, compact=True, width=120)

        # Create controlerrAdata containing the previous and next punches on the
        # same control for each errA punch.
        controlerrAdata = self._build_controlerrAdata(datain_unsorted)
        # Create dataout and siiddata
        dataout = []
        siiddata = {}

        nbrinrows = len(datain)
        if nbrinrows > 0:
            inrowno = 0
            while inrowno < nbrinrows:
                # Collect rows for one siid
                currentsiid = datain[inrowno][2]
                siidrows = []
                nbrsiidrows = 0
                while inrowno < nbrinrows and datain[inrowno][2] == currentsiid:
                    siidrows.append(datain[inrowno])
                    nbrsiidrows += 1
                    inrowno += 1
                # Lines for one siid collected. inrowno points to first line for next siid.

                # If only one row for this siid, ignore it.
                if nbrsiidrows == 1:
                    nbrsiidrows = 0
                    continue

                siidrowno = 0

                # Collect the ErrA punches for this siid
                siidfirsterrArowno = siidrowno
                siiderrAcontrols = []
                siiderrArows = []
                while siidrowno < nbrsiidrows:
                    if siidrows[siidrowno][3][13:17] == 'ErrA':
                        nbr_ErrA += 1
                        # Normal numbered control with ErrA
                        if siidrows[siidrowno][9] in CT_control_controls:
                            siiderrAcontrols.append(siidrows[siidrowno][6])
                        # Start or Finish control with ErrA
                        else:
                            siiderrAcontrols.append(siidrows[siidrowno][9])
                        siiderrArows.append(siidrows[siidrowno])
                        siidrowno += 1
                        continue
                    else:
                        break

                # Collect the pre-control punches for this siid
                siidfirstprectlrowno = siidrowno
                siidprecontrols = []
                siidprecontrolrows = []
                while siidrowno < nbrsiidrows:
                    if siidrows[siidrowno][9] in CT_pre_controls:
                        if siidrows[siidrowno][9] in CT_control_controls:
                            siidprecontrols.append(siidrows[siidrowno][6])
                        else:
                            siidprecontrols.append(siidrows[siidrowno][9])
                        siidprecontrolrows.append(siidrows[siidrowno])
                        siidrowno += 1
                        continue
                    else:
                        break

                # If no more punches after the pre-controls, ignore this siid.
                if siidrowno >= nbrsiidrows and len(siiderrAcontrols) == 0:
                    nbrsiidrows = 0
                    continue

                # Collect all the race punches for this siid
                siidfirstracerowno = siidrowno
                siidracecontrols = []
                siidracetimes = []
                siidracerows = []
                while siidrowno < nbrsiidrows:
                    if siidrows[siidrowno][9] in CT_control_controls:
                        siidracecontrols.append(siidrows[siidrowno][6])
                    else:
                        siidracecontrols.append(siidrows[siidrowno][9])
                    siidracetimes.append(datetime.datetime.strptime(siidrows[siidrowno][3] + '000',
                                                                    '%Y-%m-%d   %H:%M:%S.%f'))
                    siidracerows.append(siidrows[siidrowno])
                    siidrowno += 1

                # If both Start and Finish are missing and there are no ErrA punches, ignore.
                # This is certainly from setting out the controls.
                # Only do the ignore, if it is permitted by the config file setting.
                if rp.ignore_setout:
                    if siidracerows[0][9] not in CT_start_controls \
                            and siidracerows[-1][9] not in CT_finish_controls \
                            and len(siiderrAcontrols) == 0:
                        nbrsiidrows = 0
                        continue

                # Check if the sequence of punches corresponds exactly to
                # one of the courses.
                siidcoursename = None
                if coursesxml_exists:
                    for coursename, coursedata in courses.items():
                        if siidracecontrols == coursedata[KEYCD_Controls]:
                            siidcoursename = coursename
                            if 'Sumtimes' not in coursedata:
                                courses[coursename][KEYCD_SumTimes] = [0] * len(siidracecontrols)
                                courses[coursename][KEYCD_NbrTimes] = 0
                            courses[coursename][KEYCD_NbrTimes] += 1
                            for legno in range(1, len(siidracecontrols)):
                                splitsecs = int((siidracetimes[legno] - siidracetimes[legno - 1]).total_seconds())
                                courses[coursename][KEYCD_SumTimes][legno] += splitsecs

                # Save the data for this siid in siiddata.
                siiddata[currentsiid] = {}
                siiddata[currentsiid][KEYSI_ErrAControls] = siiderrAcontrols
                siiddata[currentsiid][KEYSI_ErrARows] = siiderrArows
                siiddata[currentsiid][KEYSI_PreControls] = siidprecontrols
                siiddata[currentsiid][KEYSI_PreControlRows] = siidprecontrolrows
                siiddata[currentsiid][KEYSI_RaceControls] = siidracecontrols
                siiddata[currentsiid][KEYSI_RaceTimes] = siidracetimes
                siiddata[currentsiid][KEYSI_RaceRows] = siidracerows
                siiddata[currentsiid][KEYSI_CourseName] = siidcoursename

                # Move the lines for this siid to dataout.
                if nbrsiidrows > 0:
                    for siidrowno in range(nbrsiidrows):
                        dataout.append(siidrows[siidrowno])

            if coursesxml_exists:
                if rp.debug:
                    rp.srv.print('Courses completed:')
                    rp.srv.print(pprint.pformat(courses,
                                                compact=True, width=120))

        if rp.debug:
            with open("dataoutpretty.txt", "w") as log_file:
                pprint.pprint(dataout, log_file, compact=True, width=120)
            with open("siiddatapretty.txt", "w") as log_file:
                pprint.pprint(siiddata, log_file, compact=True, width=120)

        # Handle each siid that has errA punches.
        if approve_errA and coursesxml_exists:
            for siidkey, siid in siiddata.items():
                # If no errA punches for this siid, nothing to handle.
                errActls = siid[KEYSI_ErrAControls]
                if len(errActls) == 0:
                    continue

                # If Start and Finish are not the first and last controls, skip cleaning up.
                racectls = siid[KEYSI_RaceControls]
                if racectls[0] not in CT_start_controls or racectls[-1] not in CT_finish_controls:
                    continue

                # Do a first attempt to compare the race to the courses to try to find extra punches
                # that do not disqualify the race. They will be removed to not disturb the logic when trying to
                # include the errA punches.
                matching_course_found = False
                # Try the siid against each course.
                for coursename, course in courses.items():
                    coursectls = course[KEYCD_Controls]
                    if rp.debug:
                        rp.srv.print(racectls)
                        rp.srv.print(coursectls)
                    foundrace, raceerrAinxs, raceextrapunchinxs \
                        = self._cmpcourse(racectls, coursectls, errActls, siidkey)

                    # The siid matches this course.
                    if foundrace == coursectls:
                        matching_course_found = True
                        # If there are extra punches that do not disqualify, mark them for deletion.
                        if len(raceextrapunchinxs) > 0:
                            for raceextrapunchinx in raceextrapunchinxs:
                                siiddata[siidkey][KEYSI_RaceControls][raceextrapunchinx] = 'X'
                                siiddata[siidkey][KEYSI_RaceTimes][raceextrapunchinx] = 'X'
                                siiddata[siidkey][KEYSI_RaceRows][raceextrapunchinx] = 'X'
                            newlist = []
                            # Delete the extra punches in each relevant list.
                            for listitem in siiddata[siidkey][KEYSI_RaceControls]:
                                if not listitem == 'X':
                                    newlist.append(listitem)
                            siiddata[siidkey][KEYSI_RaceControls] = newlist
                            newlist = []
                            for listitem in siiddata[siidkey][KEYSI_RaceTimes]:
                                if not listitem == 'X':
                                    newlist.append(listitem)
                            siiddata[siidkey][KEYSI_RaceTimes] = newlist
                            newlist = []
                            for listitem in siiddata[siidkey][KEYSI_RaceRows]:
                                if not listitem == 'X':
                                    newlist.append(listitem)
                            siiddata[siidkey][KEYSI_RaceRows] = newlist
                        break

                # If we had a match, do the matching once more with the extra controls removed.
                if matching_course_found:
                    racectls = siid[KEYSI_RaceControls]
                    course = courses[coursename]
                    coursectls = course[KEYCD_Controls]
                    if rp.debug:
                        rp.srv.print(racectls)
                        rp.srv.print(coursectls)
                    foundrace, raceerrAinxs, raceextrapunchinxs \
                        = self._cmpcourse(racectls, coursectls, errActls, siidkey)
                    if foundrace == coursectls:
                        if len(raceextrapunchinxs) > 0:
                            rp.srv.print('Extra punches found second time thru')
                            exit(1)
                        if rp.debug:
                            rp.srv.print(f'SIID key: {siidkey}')
                            rp.srv.print('Siid:')
                            rp.srv.print(pprint.pformat(siid,
                                                        compact=True, width=120))
                            rp.srv.print(f'SIID key: {siidkey}')
                            rp.srv.print(f'Course controls: {coursectls}')
                            rp.srv.print(f'Race controls: {racectls}')
                            rp.srv.print(f'Found race: {foundrace}')
                            rp.srv.print(f'ErrA indexes: {raceerrAinxs}')
                        errAinxs_to_update = \
                            self._interpolate_times(siid[KEYSI_RaceTimes],
                                                    raceerrAinxs,
                                                    siiddata[siidkey][KEYSI_ErrARows],
                                                    controlerrAdata,
                                                    course)
                        if rp.debug:
                            rp.srv.print(f'ErrA indexes to update: '
                                         f'{errAinxs_to_update}')
                        newlist = []
                        for errAinx, newdatetime in errAinxs_to_update:
                            nbr_ErrA_interpolated += 1
                            newdatetime_str = \
                                datetime.datetime.strftime(newdatetime,
                                                    '%Y-%m-%d   %H:%M:%S.%f')[:25]
                            newtime_str = newdatetime_str[13:]
                            siiddata[siidkey][KEYSI_ErrARows][errAinx][3] = newdatetime_str
                            siiddata[siidkey][KEYSI_ErrARows][errAinx][8] = newtime_str
                            newlist.append(siiddata[siidkey][KEYSI_ErrARows][errAinx])
                        siiddata[siidkey][KEYSI_ErrARows] = newlist
                    else:
                        rp.srv.print('No match second time thru.')
                        exit(1)

        if approve_errA:
            rp.srv.print(f'Number of ErrA punches: {nbr_ErrA}, '
                         f'Interpolated: {nbr_ErrA_interpolated}')

        # Rebuild dataout.
        dataoutnew = []
        for siidkey, siid in siiddata.items():
            for row in siid[KEYSI_PreControlRows]:
                dataoutnew.append(row)
            for row in siid[KEYSI_RaceRows]:
                dataoutnew.append(row)
            for row in siid[KEYSI_ErrARows]:
                dataoutnew.append(row)

        dataoutnew.sort(key=operator.itemgetter(2, 8))
        if rp.debug:
            with open("dataoutnewpretty.txt", "w") as log_file:
                pprint.pprint(dataoutnew, log_file, compact=True, width=120)

        return dataoutnew

    def _build_controlerrAdata(self, datain_unsorted):
        """This is a subfunction of errA_punchtimes.
        Create controlerrAdata containing punch times of the previous and next punches on the
        same control for each errA punch.

        :param: datain_unsorted: List containing the deta of all collected punches.
                They might have been updated with start times from Eventor and had
                their punch times corrected.

        :return: controlerrAdata: Directory with key = unique idnbr of each errA punch.
                                  Data is the punch times before and after the sequence
                                  of errA punches that this punch belongs to.
        """
        controlerrAdata = {}

        nbrinrows = len(datain_unsorted)
        if nbrinrows > 0:
            inrowno = 0
            while inrowno < nbrinrows:
                # Collect rows for one control

                # Id of the control is serialno + control type + control number
                currentcontrolid = [datain_unsorted[inrowno][5],
                                    datain_unsorted[inrowno][9],
                                    datain_unsorted[inrowno][6]]
                controlrows = []
                nbrcontrolrows = 0
                while inrowno < nbrinrows and \
                      [datain_unsorted[inrowno][5],
                       datain_unsorted[inrowno][9],
                       datain_unsorted[inrowno][6]] \
                            == currentcontrolid:
                    controlrows.append(datain_unsorted[inrowno])
                    nbrcontrolrows += 1
                    inrowno += 1
                # Lines for one control collected. inrowno points to first line for next control.

                controlrowno = 0

                # Find the ErrA punches for this control
                controlprevtime = None
                controlnexttime = None
                controlrowno = 0
                while True:
                    if controlrowno >= nbrcontrolrows:
                        break
                    controlrowseqnbr = controlrows[controlrowno][0]
                    controlrowtime = controlrows[controlrowno][3]
                    # If we have a time in this control earlier than in previous control,
                    # ignore the time in previous control.
                    # if controlprevtime is not None:
                    #     if controlrowtime < controlprevtime:
                    #         controlprevtime = None
                    # This is ErrA control
                    if controlrowtime[13:17] == 'ErrA':
                        addrow = 1
                        while True:
                            # We are at the last control so there is no next control.
                            if (newrow := controlrowno +  addrow) >= nbrcontrolrows:
                                controlnexttime = None
                                break
                            # Next control is not ErrA, so it has a valid time.
                            elif controlrows[newrow][3][13:17] != 'ErrA':
                                controlnexttime = controlrows[newrow][3]
                                break
                            # Next control is also ErrA, so not time to remember time of next control.
                            else:
                                addrow += 1

                        if controlprevtime is not None:
                            controlprevtime_dt = datetime.datetime.strptime(controlprevtime + '000',
                                                                            '%Y-%m-%d   %H:%M:%S.%f')
                        if controlnexttime is not None:
                            controlnexttime_dt = datetime.datetime.strptime(controlnexttime + '000',
                                                                            '%Y-%m-%d   %H:%M:%S.%f')
                            intvllength = (controlnexttime_dt - controlprevtime_dt).total_seconds()
                        controlerrAdata[controlrowseqnbr] = [controlprevtime_dt, controlnexttime_dt, intvllength]
                    # This is not an ErrA control, so remember as time of previous control.
                    else:
                        controlprevtime = controlrowtime

                    # Look at next control row.
                    controlrowno += 1

                # Look at next inrow.
                inrowno += 1

            if rp.debug:
                rp.srv.print('controlerrAdata:')
                rp.srv.print(pprint.pformat(controlerrAdata,
                                            compact=True, width=120))

        return controlerrAdata

    def _cmpcourse(self, racectls, coursectls, arg_errActls, siidkey):
        """This is a subfunction of errA_punchtimes.
        Compare a race to a course to find out if it as a valid race on this course,
        alse considering the errA punches.

        :param: racectls: List of valid punches registered for this race.
                coursectls: List of punches expected for this course.
                arg_errActls: List of controls for this race that were registered as errA.
                siidkey: The siid used in this race.

        :return: Tuple:
                 foundrace:    Race punches when errA controls are included in a proper way.
                 raceerrAinxs: The indexes in foundrace that are errA punches qualifying
                               for punch time interpolation.
                 raceextrapunchinxs:
                               The indexes in foundrace that are extra punches that do not
                               disqualify the race.
        """
        # Make a copy of the ErrA controls, since entries will be deleted from it.
        if rp.debug:
            rp.srv.print(siidkey)
        errActls = copy.deepcopy(arg_errActls)
        foundrace = []
        raceerrAinxs = []
        raceextrapunchinxs = []
        racectlnbr = 0
        coursectlnbr = 0
        while True:
            # Check if we have reached the end of the race controls or the course controls.
            if racectlnbr >= len(racectls) or coursectlnbr >= len(coursectls):
                break

            # Race control matches course control
            if racectls[racectlnbr] == coursectls[coursectlnbr]:
                foundrace.append(racectls[racectlnbr])
                racectlnbr += 1
                coursectlnbr += 1
                continue

            # No match, go forward among race controls to see if there is a later match to this course control
            addracectlnbr = 1
            racectlfnd = False
            racectlfnd_among_errA = False
            errAinx_found = None
            while (newracectlnbr := racectlnbr + addracectlnbr) < len(racectls):
                if racectls[newracectlnbr] == coursectls[coursectlnbr]:
                    racectlfnd = True
                    break
                addracectlnbr += 1

            # No match and no later matching race control found, check if there is a match among the errA controls.
            if not racectlfnd or (racectlfnd and addracectlnbr > 1):
                try:
                    errAinx_found = errActls.index(coursectls[coursectlnbr])
                    racectlfnd_among_errA = True
                except ValueError:
                    pass

            # No match, go forward among course controls to see if there is a later match to this race control
            addcoursectlnbr = 1
            coursectlfnd = False
            while (newcoursectlnbr := coursectlnbr + addcoursectlnbr) < len(coursectls):
                if racectls[racectlnbr] == coursectls[newcoursectlnbr]:
                    coursectlfnd = True
                    break
                else:
                    addcoursectlnbr += 1

            # We found a match when going forward among the race controls and the course control was not
            # among the errA controls in the race.
            # Assume that the race controls that we bypassed are erroneus punches, before punching the correct one.
            # Do not save the erroneus controls and restart checking after the new match.
            if (coursectlfnd and not racectlfnd_among_errA) \
              or racectlfnd:
                if racectlfnd:
                    raceextrapunchinxs.extend(range(racectlnbr, newracectlnbr))
                    racectlnbr = newracectlnbr
                if coursectlfnd:
                    coursectlnbr += 1
                continue

            # The missing race control is among the errA controls.
            #
            # Restart checking after the new match.
            elif racectlfnd_among_errA:
                foundrace.append(coursectls[coursectlnbr])
                del errActls[errAinx_found]
                raceerrAinxs.append(len(foundrace) - 1)
                coursectlnbr += 1
                continue

            # We have not found any relevant control match.
            else:
                break

        return foundrace, raceerrAinxs, raceextrapunchinxs

    def _interpolate_times(self,
                           racetimes,
                           raceerrAinxs,
                           errArows,
                           controlerrAdata,
                           course):
        """This is a subfunction of errA_punchtimes.
        Compare a race to a course to find out if it as a valid race on this course,
        alse considering the errA punches.

        :param: racetimes:    List of punch times corresponding to the controls registered
                              in racecontrols (the controls where a valid time has been
                              registered.
                raceerrAinxs: The indexes in foundrace that are errA punches qualifying
                              for punch time interpolation.
                errArows:     List of punch rows for this race that have errA punches.
                controlerrAdata:
                              Directory with key = unique idnbr of each errA punch.
                              Data is the punch times before and after the sequence
                              of errA punches that this punch belongs to.
                course:       The course directory that we are matching.

        :return: errAinxs-to-update:
                              List of tuples.
                              Each tuple contains:
                              - Index in errArows where the punch time is to be set
                              - The new datetime to be set.
        """

        # We set most of the loop indexes manually in this loop as we need to modify them occcasionally.

        # This loop examines all the punches that got errA for the current runner.
        # If there is a sequence of punches that got errA, we have to handle that sequence together to interpolate
        # the punch times correctly.

        #errAinx indexes the raceerrAinxs list. It contains the course indexes of all errA punches.
        errAinx = 0
        errAinxs_handled = 0
        errAinxs_to_update = []

        # We continue or break to iterate or get out of this loop.
        while True:
            if errAinx >= len(raceerrAinxs):
                break

            # Find the next contiguous interval of errA punches.
            errAinx_intvlstart = errAinx
            while True:
                # If we reach the end of the errAs we are ready to process the last sequence of errA punches.
                if errAinx >= len(raceerrAinxs) - 1:
                    break
                # If the next errA is the next contiguous control, it is part of the sequence.
                if raceerrAinxs[errAinx + 1] == raceerrAinxs[errAinx] + 1:
                    errAinx += 1
                    continue
                # The next errA is not contiguous, so break to handle this sequence.
                break

            # We have found a sequence (is mostly of length 1).
            errAinx_intvlend = errAinx + 1
            errAinx_intvllen = errAinx_intvlend - errAinx_intvlstart

            # If the first errA in the sequence is the first control (i.e. the Start punch),
            # we cannot do anything about it, so forget this errA.
            # Otherwise, mark the previous control as the control before the first errA.
            # When we set raceinxbefore, we must subtract the number of errA already handled.
            if (raceinxbefore := raceerrAinxs[errAinx_intvlstart] - errAinxs_handled - 1) < 0:
                errAinx = errAinx_intvlend
                continue

            # The next control in the not corrected race is the next control (since we do not have
            # times for the controls in the current errA sequence).
            # If the next control does not exist, we cannot handle this sequence of errA, so ignore it.
            if (raceinxafter := raceinxbefore + 1) >= len(racetimes):
                errAinx = errAinx_intvlend
                continue

            # Get the times before and after the errA sequence and compute
            # the total time to be allocated to the legs around the errA punches.
            timebefore = racetimes[raceinxbefore]
            timeafter = racetimes[raceinxafter]
            totalintvltime = (timeafter - timebefore).total_seconds()

            # Compute the parts as the mean value for all runners who have correctly punched all controls in the race.
            # If there are no such runners, use the length of the legs to allocate the times.
            # The leg lengths are stored as strings, so make them integers.
            parts = []
            courseinxstart = raceinxbefore + 1
            courseinxend = courseinxstart + errAinx_intvllen
            for courseinx in range(courseinxstart, courseinxend + 1):
                if course[KEYCD_NbrTimes] > 0:
                    parts.append(course[KEYCD_SumTimes][courseinx])
                else:
                    parts.append(int(course[KEYCD_LegLength][courseinx]))
            partstotal = sum(parts)

            # Compute the times to be given to the errA punches.
            partsinx = 0
            partssum = 0
            newdatetimes = []
            for updateinx in range(errAinx_intvlstart, errAinx_intvlend):
                partssum += parts[partsinx]
                newdatetime = timebefore \
                              + datetime.timedelta(seconds=(partssum / partstotal) * totalintvltime)
                uncorrected_newdatetime = newdatetime
                # Check if this is a possible punch time with regard to the punches before
                # and after at the same control.
                punchnbr = errArows[updateinx][0]
                earlytime, latetime, diffseconds = controlerrAdata[punchnbr]
                if diffseconds < 10.0:
                    if newdatetime <= earlytime or newdatetime >= latetime:
                        newdatetime = earlytime + (latetime - earlytime) / 2
                else:
                    if newdatetime <= earlytime:
                        newdatetime = earlytime + datetime.timedelta(seconds=5)
                    elif newdatetime >= latetime:
                        newdatetime = latetime - datetime.timedelta(seconds=5)
                if rp.debug:
                    rp.srv.print(f'Uncorrected {uncorrected_newdatetime} '
                                 f'changed to {newdatetime}')
                    rp.srv.print(f' Possible interval {earlytime} - {latetime}')
                errAinxs_to_update.append((updateinx, newdatetime))
                errAinxs_handled += 1
                partsinx += 1

            # Check if we can get better times by looking at the time intervals where the errA punches
            # must have occurred.
            # reviseddatetimes = revise_errA_times(newdatetimes, timebefore, timeafter, )
            # The next errA to be considered is the one after the last one in the current sequence.
            errAinx = errAinx_intvlend

        return errAinxs_to_update


    def getstarttimes(self):
        """For classes with fixed start times and no start punching, this method reads the start times xml file
           from Eventor and creates an excel file with all fixed start times.
           The excel file is later read by the create method to insert the fixed start times in the output file
           from create.

        :param:

        :return:
        """
        # Check if the file with start times, that was loaded to Eventor, has been provided.
        if not os.path.exists(rp.starttimes_eventor):
            rp.srv.print(f'File {rp.starttimes_eventor} does not exist.\n'
                         f'Please export it from Eventor and name '
                         f'it {rp.starttimes_eventor}\n'
                         f'before running this procedure.')
            sys.exit(1)

        # Read the file
        with open(rp.starttimes_eventor, 'r', encoding='utf-8') as file:
            xmldata = file.read()
        # Parse the xml file using the xmltodict module.
        tree = xmltodict.parse(xmldata)
        excellines = []
        classstart = tree[KEYSX_StartList][KEYSX_ClassStart]
        for runclass in classstart:
            curclass = runclass[KEYSX_Class][KEYSX_Name]
            for personstart in runclass[KEYSX_PersonStart]:
                if 'ControlCard' not in personstart[KEYSX_Start]:
                    continue
                familyname = personstart[KEYSX_Person][KEYSX_Name][KEYSX_Family]
                givenname = personstart[KEYSX_Person][KEYSX_Name][KEYSX_Given]
                club = personstart[KEYSX_Organisation][KEYSX_Name]
                startdatetime = personstart[KEYSX_Start][KEYSX_StartTime]
                startdate = startdatetime[:10]
                starttime = startdatetime[11:19]
                sicard = personstart[KEYSX_Start][KEYSX_ControlCard]
                # Build a tuple for the cells for one excel line.
                excelline = (sicard, startdate, starttime, f'{givenname} {familyname}', club, curclass)
                excellines.append(excelline)

        # Create an excel file from the values collected.
        start = Workbook()
        starts = start.active
        starts.title = 'Start times'
        headers = ('SI Number', 'Start date', 'Start time', 'Name', 'Club', 'Classx')

        starts.append(headers)
        starts.column_dimensions['A'].width = 12
        starts.column_dimensions['B'].width = 12
        starts.column_dimensions['C'].width = 10
        starts.column_dimensions['D'].width = 30
        starts.column_dimensions['E'].width = 30
        starts.column_dimensions['F'].width = 18
        for excelline in excellines:
            starts.append(excelline)
        start.save(filename=rp.starttimes_corrected)
        rp.srv.print(f'File {rp.starttimes_corrected} has been created.\n'
                     f'Open it and check if manual correctionas are necessary.')


    def create(self):
        """Create a readout file in the same format as SIConfig would create from
           a SI Readout unit.
           If start times from Eventor have been provided, get them from the excel file Starttimes.xlsx.

        :param:

        :return:
        """

        # This is the beginning of code for the "create" method

        # Check if there is a lastmeosbackup file and not a lastmeosbackup_cleaned file
        remove_cards_already_read_out = False
        if os.path.exists(rp.lastmeosbackup) \
        and not os.path.exists(rp.lastmeosbackup_cleaned):
            rp.srv.print(35 * '= ')
            rp.srv.print(f'File {rp.lastmeosbackup} exists but not '
                         f'{rp.lastmeosbackup_cleaned}.\n'
                         f'Therefore the results in {rp.lastmeosbackup} '
                         f'that have already\n'
                         f'been read out will be kept, by removing them from\n'
                         f'the Readout file created by this function.\n'
                         f'That way they will not be fed into MeOS once more.\n'
                         f'Make sure that you import the {rp.lastmeosbackup} '
                         f'file to MeOS before\n'
                         f'importing the Readout file from this function.')
            rp.srv.print(35 * '= ')

            # If so, get the SI cards already read out from the lastmeosbackup file
            remove_cards_already_read_out = True
            read_out_cards = self._find_cards_read_out()

        # Read the sorted file from the joinfiles method and collect the data in datain.
        datain = []
        inrownbr = 0
        with open(rp.join_sorted_file) as csv_file:
            csvreader = csv.reader(csv_file, delimiter=';')

            for row in csvreader:
                inrownbr += 1
                if inrownbr > 1:
                    datain.append(row)

        # Prepare a list of lists for the readout data file.
        dataout = []

        # Create the header line
        header_string = 'No;Read on;SIID;Start no;Clear CN;Clear DOW;Clear time;Clear_r CN;Clear_r DOW;' + \
                        'Clear_r time;Check CN;Check DOW;Check time;Start CN;Start DOW;Start time;Start_r CN;' + \
                        'Start_r DOW;Start_r time;Finish CN;Finish DOW;Finish time;Finish_r CN;Finish_r DOW;' + \
                        'Finish_r time;Class;First name;Last name;Club;Country;Email;Date of birth;Sex;Phone;' + \
                        'Street;ZIP;City;Hardware version;Software version;Battery date;Battery voltage;' + \
                        'Clear count;Character set;SEL_FEEDBACK;No. of records;'

        for punchno in range(1, 193):
            punchheader = 'Record ' + str(punchno) + ' '
            header_string += punchheader + 'CN;' + punchheader + 'DOW;' + punchheader + 'time;'

        # Remove the last semicolon and put the header line in dataout
        header_string = header_string[:-1]
        headers = header_string.split(';')
        dataout.append(headers)

        # Initiate variables to control the loop
        inrowno = -1
        outrowno = 0
        current_siid = ''

        # Loop running through all punches
        while True:

            # Next line in input data. Data starts on second line, bypassing the header line.
            inrowno += 1

            # The tests below only to be done if we have not reached the end of data.
            if inrowno < len(datain):

                # If it is not the last data line
                if inrowno < len(datain) - 1:

                    # If next line is for the same SIID as the current line
                    if datain[inrowno][2] == datain[inrowno + 1][2]:

                        # If both this line and the next are Start punches, the runner has punched Start
                        # more than once. Ignore this line and rather use the next Start punch.
                        if datain[inrowno][9] in CT_start_controls and \
                                datain[inrowno + 1][9] in CT_start_controls:
                            continue

            # The first test means end of data,
            # the second indicates a new SIID on this line,
            # the third indicates a new sequence of Clear, Check, and/or Start punches
            # with the same SIID, so it is reuse of the same SI card.
            # In all these cases it is time to create a new line for the Readout data file.
            if inrowno >= len(datain) or \
                    current_siid != datain[inrowno][2] or \
                    (inrowno > 1 \
                     and datain[inrowno][9] in CT_breaking_controls \
                     and datain[inrowno - 1][9] not in CT_breaking_controls \
                    ):
            # If this is not the first runner, store the number of punches in the old line
                # and save it as a new output line.
                if current_siid != '':
                    newoutrow[44] = nbrcontrols
                    if remove_cards_already_read_out:
                        if newoutrow[2] not in read_out_cards:
                            dataout.append(newoutrow)
                        else:
                            # Decrease outrowno as no new row is written.
                            outrowno -= 1
                    else:
                        dataout.append(newoutrow)

                # If this is end of data, leave the loop.
                if inrowno >= len(datain):
                    break

                # Now we start handling a new output line.
                outrowno += 1
                nbrcontrols = 0
                outcolno = 45  # Punch data start in column 46

                # Readout time is in column 2
                readtime = datain[inrowno][1]

                # SIID is in column 3
                current_siid = datain[inrowno][2]

                # The first four output columns contain:
                # Line number, Readout time, SIID, and constant 1
                newoutrow = [''] * 45
                newoutrow[0] = outrowno
                newoutrow[1] = readtime
                newoutrow[2] = current_siid
                newoutrow[3] = 1

            # Get the punch time from column 9
            punchtime = str(datain[inrowno][8])[0:8]

            # Start time is in column 16 of the output file
            if datain[inrowno][9] in CT_start_controls:
                newoutrow[15] = punchtime

            # Finish time is in column 22 of the output file
            if datain[inrowno][9] in CT_finish_controls:
                newoutrow[21] = punchtime

            # Clear time is set in the clear and check columns 7 and 13 of the output file
            if datain[inrowno][9] == CT_Clear:
                newoutrow[6] = punchtime
                newoutrow[12] = punchtime

            # Check time is in column 7 and 13 of the output file and the clear time
            # is moved to column 10 to mimic the behaviour of SIConfigPlus found empirically and
            # susggested  by https://www.attackpoint.org/discussionthread.jsp/message_1475911.
            if datain[inrowno][9] == CT_Check:
                newoutrow[9] = newoutrow[6]
                newoutrow[6] = punchtime
                newoutrow[12] = punchtime

            # This is a control punch, its data are to be put in the next 3 columns.
            if datain[inrowno][9] in CT_control_controls:
                controlno = datain[inrowno][6]
                newoutrow.append(controlno)
                newoutrow.append('')
                newoutrow.append(punchtime)
                outcolno += 3
                nbrcontrols += 1

        # Everything is read and the output is built, save the built Readout file.
        with open(rp.create_out_file, mode='w', newline='') as outfile:
            outfile_writer = csv.writer(outfile, delimiter=';', quotechar="'", quoting=csv.QUOTE_MINIMAL)

            for row in dataout:
                outfile_writer.writerow(row)

        rp.srv.print(f'{outrowno + 1} data lines written to {rp.create_out_file}')

    def _find_cards_read_out(self):
        """Internal procedure to retrieve SI Card numbers from lastbackup.meosxml that
           do not have a <Finished> block.

        :param:
        :return: set of SI Card numbers
        """
        # Read the file
        with open(rp.lastmeosbackup, 'r', encoding='utf-8') as file:
            xmldata = file.read()
        # Parse the xml file using the xmltodict module.
        tree = xmltodict.parse(xmldata)

        # If the runner has a Finish block, store his SI Card number in a set.
        readout_sicards = set()
        for runner in tree['meosdata']['RunnerList']['Runner']:
            if 'Finish' in runner:
                readout_sicards.add(runner['CardNo'])
        return readout_sicards

    def cleanmeosbackup(self):
        """Remove all registered SI card punches from a MeOS backup file
           to make it look like a backup with only registered runners without any results yet.

        :param:

        :return:
        """
        # Check if the MeOS backup file has been provided.
        if not os.path.exists(rp.lastmeosbackup):
            rp.srv.print(f'File {rp.lastmeosbackup} does not exist.\n'
                         f'Please copy your last MeOS backup and name '
                         f'it {rp.lastmeosbackup}\n'
                         f'before running this procedure.')
            sys.exit(1)

        # Read the file
        with open(rp.lastmeosbackup, 'r', encoding='utf-8') as file:
            xmldata = file.read()
        # Parse the xml file using the xmltodict module.
        tree = xmltodict.parse(xmldata)

        # Remove the Card and Finish blocks for all runners.
        for runner in tree[KEYLX_meosdata][KEYLX_RunnerList][KEYLX_Runner]:
            if KEYLX_Card in runner:
                del runner[KEYLX_Card]
            if KEYLX_Finish in runner:
                del runner[KEYLX_Finish]

        # Remove the contents of the CardList and PunchList blocks.
        del tree[KEYLX_meosdata][KEYLX_CardList][KEYLX_Card]
        del tree[KEYLX_meosdata][KEYLX_PunchList][KEYLX_Punch]

        # Recreate the meosxml file and write it to a new "cleaned" file.
        xmldata = xmltodict.unparse(tree, pretty=True)
        with open(rp.lastmeosbackup_cleaned, 'w', encoding='utf-8') as file:
            file.write(xmldata)
        rp.srv.print(f'MeOS backup file cleaned, {rp.lastmeosbackup_cleaned} '
                     f'has been created.')


class Service(object):
    """Class to handle common service functions:
        Logging
    """

    def __init__(self, config) -> None:
        """__init__

        :param config: Configuration data
        :return:
        """

        self.cfg = config
        self.logfile = self.cfg["Files"]["Logfile"]

    def writelog(self, text: str):
        """Write one or more lines to the log file.

        :param text: Text string to write. A newline is appended at the end
                     of the text.
        :return:
        """
        with open(self.logfile, "a") as f:
            f.write(f"{str(datetime.datetime.now())[:19]} {text}\n")

    def print(self, text: str):
        """Print one or more lines and write them to the log file.

        :param text: Text string to write and print.
        :return:
        """
        print(text)
        self.writelog(text)

    def validate_date(self, date):
        """Validate date string or make a string from type datetime.

        :param date: Date string or type datetime.
        :return: valid (True/False),
                 date as string
        """
        valid= True
        if type(date) is datetime.datetime:
            datestr = str(date)[:10]
        else:
            datestr = str(date)
            try:
                datetime.datetime.strptime(datestr, '%Y-%m-%d')
            except ValueError:
                valid = False
        return valid, datestr

    def validate_time(self, time):
        """Validate time string or make a string from type time.

        :param time: Time string or type time.
        :return: valid (True/False),
                 time as string
        """
        valid = True
        if type(time) is datetime.time:
            timestr = str(time)[:8]
        else:
            timestr = str(time)
            try:
                datetime.datetime.strptime(timestr, '%H:%M:%S')
            except ValueError:
                valid = False
        return valid, timestr

    def ask_user(self, msg):
        """Give user a question. Return the answer.
        The answer is always returned as an upper case string.

        :param msg: The message to present.
        :return: Answer as upper case string.
        """
        self.writelog(msg)
        answer = input(msg)
        answer = answer.strip().upper()
        self.writelog(f'Reply: {answer}')
        return answer

    def user_positive(self, msg):
        """Give user a yes/no question and return True if the
        answer is yes, otherwise return False.

        :param msg: The message to present. The message is
                    appended with a request to answer yes or no.
        :return: True if answer is yes, otherwise False.
        """
        msgout = msg + '\nPlease reply y/n for yes/no.'
        self.writelog(msgout)
        answer = input(msgout)
        answer2 = answer.strip().upper()
        self.writelog(f'Reply: {answer2}')
        return answer2 in ('Y', 'J')


class RunPgm(object):
    """Class for running this program.
    """

    def __init__(self):
        """Instantiate the classes needed to run the program.
            Read the configuration file.
            Initiate values used in the run loop.

        :param
        :return:
        """

        self.cfg = configparser.ConfigParser()
        self.cfg.read("OrruSI.cfg")
        self.srv = Service(config=self.cfg)
        self.adj = Adjustments()
        self.dummy_racedate = '2011-11-11'
        self._checkconfig()

    def run(self):
        """Run the program.

        :param
        :return:
        """
        # Set the size of the command line window
        os.system(f'mode con: cols={self.window_columns} lines={self.window_lines}')

        # Check parameters
        if len(sys.argv) < 2:
            parm = 'None'
        else:
            parm = sys.argv[1]

        if parm not in ['-join', '-create', '-getstarttimes', '-readcu', '-cleanmeosbackup']:
            rp.srv.print('Invalid argument: ', parm)
            sys.exit(1)

        self.reconstruction = Do_reconstruction()

        # Perform the function that was requested
        rp.srv.print(f'Function {parm} is started.')
        if parm == '-readcu':
            self.reconstruction.readcu()

        if parm == '-join':
            self.reconstruction.joinfiles()

        if parm == '-getstarttimes':
            self.reconstruction.getstarttimes()

        if parm == '-create':
            self.reconstruction.create()

        if parm == '-cleanmeosbackup':
            self.reconstruction.cleanmeosbackup()
        rp.srv.print(f'Function {parm} has successfully finished.')

    def _checkconfig(self):
        """Check the config file and get values from it
        """
        self.adjustments_file = self.cfg["Files"]["Adjustments"]
        self.adjustments_backup = self.cfg["Files"]["Adjustments_backup"]
        self.starttimes_eventor = self.cfg["Files"]["Starttimes_Eventor"]
        self.starttimes_corrected = self.cfg["Files"]["Starttimes_Corrected"]
        self.lastmeosbackup = self.cfg["Files"]["Last_MeOS_Backup"]
        self.lastmeosbackup_cleaned = self.cfg["Files"]["Last_MeOS_Backup_Cleaned"]
        self.courses_xml = self.cfg["Files"]["Courses"]
        self.sheet1name = self.cfg["Files"]["Sheet1_name"]
        self.sheet2name = self.cfg["Files"]["Sheet2_name"]
        self.punches_subdir = self.cfg["Files"]["Punches_subdir"]
        self.join_unsorted_file = self.cfg["Files"]["Join_outfile_unsorted"]
        self.join_sorted_file = self.cfg["Files"]["Join_outfile_sorted"]
        self.create_out_file = self.cfg["Files"]["Create_outfile"]
        self.window_lines = self.cfg["Window"]["Lines"]
        self.window_columns = self.cfg["Window"]["Columns"]

        turnoff = self.cfg["Actions"]["SI_turnoff"]
        self.si_turnoff = False
        if len(turnoff) > 0:
            if turnoff.upper()[0] in ('Y', 'J'):
                self.si_turnoff = True
        approve = self.cfg["Actions"]["Approve_ErrA"]
        self.approve_ErrA = False
        if len(approve) > 0:
            if approve.upper()[0] in ('Y', 'J'):
                self.approve_ErrA = True

        correct = self.cfg["Actions"]["Correct_times"]
        self.do_correct_times = False
        if len(correct) > 0:
            if correct.upper()[0] in ('Y', 'J'):
                self.do_correct_times = True

        ignore_setout = self.cfg["Actions"]["Ignore_setout_punches"]
        self.ignore_setout = False
        if len(ignore_setout) > 0:
            if ignore_setout.upper()[0] in ('Y', 'J'):
                self.ignore_setout = True

        debug = self.cfg["Actions"]["Debug"]
        self.debug = False
        if len(debug) > 0:
            if debug.upper()[0] in ('Y', 'J'):
                self.debug = True


# Start main program
if __name__ == "__main__":
    rp = RunPgm()

    # Run the program and log any exception that has not been handled on a
    # lower level, end the program with return code 1 to indicate failure.
    try:
        rp.run()
    except Exception:
        exceptiondata = traceback.format_exc()
        rp.srv.print(exceptiondata)
        sys.exit(1)
